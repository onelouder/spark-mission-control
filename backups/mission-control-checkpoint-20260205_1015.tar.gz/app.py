#!/usr/bin/env python3
"""
Mission Control - Kanban Dashboard with Email/Calendar Integration
FastAPI backend that connects to Decapoda-Lite API
"""

import json
import os
import time
import uuid
import asyncio
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any

import httpx
from fastapi import FastAPI, HTTPException, Request, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

# Import our new email modules
from contacts import refresh_contact_rankings, load_contacts
from pipeline import sync_and_process_emails, get_dashboard_data, load_processed_emails
from analyzer import test_llm_connection

# Import briefing module
from briefing import (
    generate_full_briefing, generate_active_threads, generate_weekly_pulse,
    snooze_item, unsnooze_item, mark_item_done, load_json_file, get_cached_briefing
)

# Import context aggregator for multi-source email/calendar
from context_aggregator import (
    get_aggregator, get_contexts, set_context_filter, get_context_filter,
    get_accounts, set_account_filter, get_account_filter, get_accounts_for_context
)

# Import queue module for agent task management
from agent_queue import (
    get_all_items, get_item, create_item, update_item, delete_item,
    get_items_by_column, get_stats, open_in_helix,
    QueueItemCreate, QueueItemUpdate
)

app = FastAPI(title="Mission Control", description="Kanban Dashboard with Email/Calendar Integration")

# Serve static files
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Background task for periodic briefing refresh
async def periodic_briefing_refresh():
    """Background task that refreshes briefing cache every 15 minutes"""
    while True:
        try:
            await asyncio.sleep(15 * 60)  # 15 minutes
            print(f"[BACKGROUND] Starting periodic briefing refresh...")
            await generate_full_briefing()
            print(f"[BACKGROUND] Briefing refresh completed at {datetime.now()}")
        except Exception as e:
            print(f"[BACKGROUND] Briefing refresh failed: {e}")
            # Continue the loop even on failure

@app.on_event("startup")
async def startup_event():
    """Start background tasks on application startup"""
    print(f"[STARTUP] Starting background briefing refresh task...")
    asyncio.create_task(periodic_briefing_refresh())

# Configuration
DECAPODA_BASE_URL = "http://localhost:8766"
DATA_DIR = "data"
TASKS_FILE = os.path.join(DATA_DIR, "tasks.json")
FOCUS_FILE = os.path.join(DATA_DIR, "focus.json")

# Ensure data directory exists
os.makedirs(DATA_DIR, exist_ok=True)

# Models
class Task(BaseModel):
    id: str
    title: str
    description: Optional[str] = ""
    column: str  # unsorted, todo, inprogress, done, archive
    energy: Optional[str] = None  # high_burn, low_stakes, brain_dead
    source_type: Optional[str] = None  # email, calendar, manual
    source_id: Optional[str] = None
    source_url: Optional[str] = None
    created_at: str
    updated_at: str
    stuck_since: Optional[str] = None

class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    column: Optional[str] = None
    energy: Optional[str] = None
    notes: Optional[str] = None

class QuickTask(BaseModel):
    title: str
    column: Optional[str] = "unsorted"

class FocusSession(BaseModel):
    task_id: str
    started_at: str
    mode: str  # "timer" or "pomodoro"

class EmailAction(BaseModel):
    action: str  # "archive", "snooze", "create-task"
    
class EmailToTask(BaseModel):
    task_title: Optional[str] = None
    task_description: Optional[str] = None

# Briefing models
class SnoozeRequest(BaseModel):
    item_id: str
    type: str  # email, task, thread
    source_id: str
    title: str
    context: str
    wake_at: str
    original_block: str

class ItemDoneRequest(BaseModel):
    item_id: str
    type: str

# Data persistence
def load_tasks() -> List[Dict]:
    """Load tasks from JSON file"""
    try:
        with open(TASKS_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

def save_tasks(tasks: List[Dict]) -> None:
    """Save tasks to JSON file"""
    with open(TASKS_FILE, 'w') as f:
        json.dump(tasks, f, indent=2)

def load_focus_session() -> Optional[Dict]:
    """Load current focus session"""
    try:
        with open(FOCUS_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return None

def save_focus_session(session: Optional[Dict]) -> None:
    """Save focus session to JSON file"""
    if session is None:
        # Remove file if no active session
        try:
            os.remove(FOCUS_FILE)
        except FileNotFoundError:
            pass
    else:
        with open(FOCUS_FILE, 'w') as f:
            json.dump(session, f, indent=2)

# =============================================================================
# Helper Functions
# =============================================================================
# Note: Email classification is handled by analyzer.py (LLM-based via Ollama).
# The functions here are for task/Kanban operations only.

def get_energy_for_task(title: str) -> str:
    """Assign energy level based on task content"""
    title_lower = title.lower()
    
    if any(word in title_lower for word in ["urgent", "critical", "deadline", "important", "complex", "meeting", "decision"]):
        return "high_burn"
    elif any(word in title_lower for word in ["update", "check", "review", "organize", "file", "simple"]):
        return "brain_dead"
    else:
        return "low_stakes"

async def fetch_from_decapoda(endpoint: str) -> Dict:
    """Fetch data from Decapoda API"""
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(f"{DECAPODA_BASE_URL}{endpoint}")
            response.raise_for_status()
            return response.json()
        except httpx.RequestError as e:
            raise HTTPException(status_code=502, detail=f"Failed to connect to Decapoda API: {str(e)}")
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=f"Decapoda API error: {str(e)}")

# Routes
@app.get("/")
async def dashboard(request: Request):
    """Serve the main dashboard (Kanban)"""
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/email")
async def email_dashboard(request: Request):
    """Serve the email dashboard"""
    return templates.TemplateResponse("email.html", {"request": request})

def is_priority_contact(email_address: str, contacts: Dict) -> bool:
    """Check if email is from a priority contact (top20, top100, or partner domain)"""
    email_lower = email_address.lower()
    domain = email_lower.split("@")[-1] if "@" in email_lower else ""
    
    # Check top20
    for contact in contacts.get("top20", []):
        contact_email = contact.get("email", "").lower() if isinstance(contact, dict) else str(contact).lower()
        if contact_email == email_lower:
            return True
    
    # Check top100
    for contact in contacts.get("top100", []):
        contact_email = contact.get("email", "").lower() if isinstance(contact, dict) else str(contact).lower()
        if contact_email == email_lower:
            return True
    
    # Check partner domains
    if domain in contacts.get("partner_domains", []):
        return True
    
    # Check pinned contacts (can be strings or dicts)
    for contact in contacts.get("pinned_contacts", []):
        contact_email = contact.get("email", "").lower() if isinstance(contact, dict) else str(contact).lower()
        if contact_email == email_lower:
            return True
    
    return False


@app.get("/api/sync/email")
async def sync_email():
    """Fetch emails from Decapoda - only create tasks for priority contacts"""
    email_data = await fetch_from_decapoda("/v1/email/inbox")
    
    # Load contacts for priority check
    contacts_path = os.path.join(DATA_DIR, "contacts.json")
    contacts = {}
    if os.path.exists(contacts_path):
        with open(contacts_path) as f:
            contacts = json.load(f)
    
    tasks = load_tasks()
    existing_email_ids = {task["source_id"] for task in tasks if task["source_type"] == "email"}
    
    new_tasks = []
    current_time = datetime.now(timezone.utc).isoformat()
    
    for email in email_data.get("value", []):
        if email["id"] not in existing_email_ids and not email.get("isRead", False):
            sender_email = email["from"]["address"]
            
            # ONLY create tasks for priority contacts
            if not is_priority_contact(sender_email, contacts):
                continue
            
            # Create task for priority contact email
            task = {
                "id": str(uuid.uuid4()),
                "title": f"📧 {email['subject']}",
                "description": f"From: {email['from']['name']} <{email['from']['address']}>",
                "column": "unsorted",
                "energy": get_energy_for_task(email["subject"]),
                "source_type": "email",
                "source_id": email["id"],
                "source_url": email.get("webLink", ""),
                "created_at": current_time,
                "updated_at": current_time,
                "stuck_since": current_time,
                "priority_contact": True
            }
            new_tasks.append(task)
    
    # Add new tasks to existing tasks
    all_tasks = tasks + new_tasks
    save_tasks(all_tasks)
    
    return {"new_tasks": len(new_tasks), "tasks": new_tasks}

@app.get("/api/sync/calendar")
async def sync_calendar():
    """Fetch calendar events from Decapoda and return timeline events"""
    calendar_data = await fetch_from_decapoda("/v1/calendar/next")
    
    events = []
    for event in calendar_data.get("value", []):
        if not event.get("isCancelled", False):
            events.append({
                "id": event["id"],
                "title": event["subject"],
                "start": event["start"],
                "end": event["end"],
                "location": event.get("location", ""),
                "organizer": event["organizer"]["name"] if event.get("organizer") else "",
                "url": event.get("webLink", "")
            })
    
    return {"events": events}

@app.get("/api/tasks")
async def get_tasks():
    """Get all tasks"""
    tasks = load_tasks()
    
    # Update stuck_since for tasks that haven't moved
    current_time = datetime.now(timezone.utc).isoformat()
    for task in tasks:
        if not task.get("stuck_since"):
            task["stuck_since"] = task["updated_at"]
    
    return {"tasks": tasks}

@app.post("/api/tasks")
async def create_task(task_data: QuickTask):
    """Create a new task (from quick-add or inline add)"""
    tasks = load_tasks()
    
    # Validate column
    valid_columns = ["unsorted", "todo", "inprogress", "done", "archive"]
    column = task_data.column if task_data.column in valid_columns else "unsorted"
    
    current_time = datetime.now(timezone.utc).isoformat()
    new_task = {
        "id": str(uuid.uuid4()),
        "title": task_data.title,
        "description": "",
        "column": column,
        "energy": get_energy_for_task(task_data.title),
        "source_type": "manual",
        "source_id": None,
        "source_url": None,
        "created_at": current_time,
        "updated_at": current_time,
        "stuck_since": current_time
    }
    
    tasks.append(new_task)
    save_tasks(tasks)
    
    return new_task

@app.put("/api/tasks/{task_id}")
async def update_task(task_id: str, task_update: TaskUpdate):
    """Update a task"""
    tasks = load_tasks()
    
    task_index = None
    for i, task in enumerate(tasks):
        if task["id"] == task_id:
            task_index = i
            break
    
    if task_index is None:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Update task
    current_time = datetime.now(timezone.utc).isoformat()
    task = tasks[task_index]
    
    if task_update.title is not None:
        task["title"] = task_update.title
    if task_update.description is not None:
        task["description"] = task_update.description
    if task_update.energy is not None:
        task["energy"] = task_update.energy
    if task_update.notes is not None:
        task["notes"] = task_update.notes
    
    # If column changed, reset stuck_since
    if task_update.column is not None and task_update.column != task["column"]:
        task["column"] = task_update.column
        task["stuck_since"] = current_time
    
    task["updated_at"] = current_time
    tasks[task_index] = task
    
    save_tasks(tasks)
    return task

@app.delete("/api/tasks/{task_id}")
async def delete_task(task_id: str):
    """Delete a task"""
    tasks = load_tasks()
    
    tasks = [task for task in tasks if task["id"] != task_id]
    save_tasks(tasks)
    
    return {"deleted": True}

@app.post("/api/tasks/{task_id}/to-kanban")
async def task_to_kanban(task_id: str):
    """Move task to kanban inbox (unsorted column)"""
    tasks = load_tasks()
    
    for task in tasks:
        if task["id"] == task_id:
            task["column"] = "unsorted"
            task["show_in_briefing"] = False
            break
    
    save_tasks(tasks)
    return {"moved": True, "column": "unsorted"}

@app.post("/api/tasks/{task_id}/snooze")
async def snooze_task_endpoint(task_id: str, snooze_data: dict):
    """Snooze a task for specified hours"""
    from datetime import datetime, timezone, timedelta
    
    hours = snooze_data.get("hours", 1)
    wake_at = datetime.now(timezone.utc) + timedelta(hours=hours)
    
    tasks = load_tasks()
    for task in tasks:
        if task["id"] == task_id:
            task["snoozed_until"] = wake_at.isoformat()
            task["show_in_briefing"] = False
            break
    
    save_tasks(tasks)
    return {"snoozed": True, "wake_at": wake_at.isoformat()}

@app.delete("/api/tasks/column/{column}")
async def delete_column_tasks(column: str):
    """Delete all tasks in a column"""
    tasks = load_tasks()
    original_count = len(tasks)
    
    tasks = [task for task in tasks if task.get("column") != column]
    deleted_count = original_count - len(tasks)
    
    save_tasks(tasks)
    
    return {"deleted": deleted_count, "column": column}

@app.post("/api/focus/start")
async def start_focus(focus_data: FocusSession):
    """Start focus mode on a task"""
    # Verify task exists
    tasks = load_tasks()
    task = next((t for t in tasks if t["id"] == focus_data.task_id), None)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Save focus session
    session = {
        "task_id": focus_data.task_id,
        "task_title": task["title"],
        "started_at": focus_data.started_at,
        "mode": focus_data.mode
    }
    save_focus_session(session)
    
    return session

@app.post("/api/focus/stop")
async def stop_focus():
    """End focus mode"""
    save_focus_session(None)
    return {"stopped": True}

@app.get("/api/focus/status")
async def get_focus_status():
    """Get current focus session status"""
    session = load_focus_session()
    if session:
        # Calculate elapsed time
        started = datetime.fromisoformat(session["started_at"].replace("Z", "+00:00"))
        elapsed = datetime.now(timezone.utc) - started
        session["elapsed_seconds"] = int(elapsed.total_seconds())
    
    return {"session": session}

# Email API Routes
@app.get("/api/email/dashboard")
async def get_email_dashboard():
    """Get processed emails organized for dashboard display"""
    try:
        dashboard_data = get_dashboard_data()
        return dashboard_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get dashboard data: {str(e)}")

@app.post("/api/email/sync")
async def sync_emails():
    """Trigger email sync and processing pipeline"""
    try:
        config_data = {}
        try:
            with open(os.path.join(DATA_DIR, "config.json"), 'r') as f:
                config_data = json.load(f)
        except FileNotFoundError:
            pass
        
        max_emails = config_data.get("max_emails_per_sync", 100)
        result = await sync_and_process_emails(max_emails)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Email sync failed: {str(e)}")

@app.get("/api/email/filtered")
async def get_filtered_emails():
    """Get filtered/dropped emails for audit"""
    try:
        processed_data = load_processed_emails()
        filtered_emails = processed_data.get("filtered", {})
        
        # Format for display
        audit_data = []
        for email_id, email_data in filtered_emails.items():
            audit_data.append({
                "id": email_id,
                "subject": email_data["email_data"].get("subject", "No subject"),
                "from": email_data["email_data"].get("from", {}),
                "received": email_data["email_data"].get("received"),
                "filter_reason": email_data.get("filter_reason", "Unknown"),
                "stage": email_data.get("stages", {})
            })
        
        return {"filtered_emails": audit_data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get filtered emails: {str(e)}")


@app.get("/api/triage")
async def get_triage_queue():
    """Get emails for triage mode - one at a time processing"""
    try:
        # Get unread emails from Decapoda
        email_data = await fetch_from_decapoda("/v1/email/inbox?unread=true")
        
        # Load contacts for priority marking
        contacts_path = os.path.join(DATA_DIR, "contacts.json")
        contacts = {}
        if os.path.exists(contacts_path):
            with open(contacts_path) as f:
                contacts = json.load(f)
        
        # Load already processed/snoozed email IDs
        processed_data = load_processed_emails()
        processed_ids = set(processed_data.get("triaged", {}).keys())
        
        # Filter and enrich emails
        queue = []
        for email in email_data.get("value", []):
            if email["id"] in processed_ids:
                continue
                
            sender_email = email.get("from", {}).get("address", "")
            is_priority = is_priority_contact(sender_email, contacts)
            
            queue.append({
                "id": email["id"],
                "subject": email.get("subject", "(No subject)"),
                "from_name": email.get("from", {}).get("name", "Unknown"),
                "from_email": sender_email,
                "preview": email.get("bodyPreview", "")[:200],
                "received": email.get("receivedDateTime"),
                "is_priority": is_priority,
                "web_link": email.get("webLink", "")
            })
        
        # Sort: priority contacts first, then by date
        queue.sort(key=lambda x: (not x["is_priority"], x.get("received", "")))
        
        return {
            "queue": queue,
            "total": len(queue),
            "priority_count": sum(1 for e in queue if e["is_priority"])
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get triage queue: {str(e)}")


@app.post("/api/triage/{email_id}")
async def triage_email(email_id: str, action: str, snooze_until: Optional[str] = None):
    """Process a triaged email - archive, snooze, task, or skip"""
    try:
        processed_data = load_processed_emails()
        processed_data.setdefault("triaged", {})
        
        # Record the triage action
        processed_data["triaged"][email_id] = {
            "action": action,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "snooze_until": snooze_until
        }
        
        # Save processed data
        processed_file = os.path.join(DATA_DIR, "processed_emails.json")
        with open(processed_file, "w") as f:
            json.dump(processed_data, f, indent=2)
        
        # Execute action via Decapoda if needed
        if action == "archive":
            # Mark as read in Outlook
            await fetch_from_decapoda(f"/v1/email/{email_id}/read", method="POST")
        
        return {"success": True, "action": action}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Triage action failed: {str(e)}")


@app.post("/api/email/{email_id}/action")
async def email_action(email_id: str, action_data: EmailAction):
    """Mark email action (archive, snooze, create-task)"""
    try:
        processed_data = load_processed_emails()
        emails = processed_data.get("emails", {})
        
        if email_id not in emails:
            raise HTTPException(status_code=404, detail="Email not found")
        
        # Update email with action
        emails[email_id]["action"] = action_data.action
        emails[email_id]["action_at"] = datetime.now(timezone.utc).isoformat()
        
        # Save back to file
        processed_data["emails"] = emails
        with open(os.path.join(DATA_DIR, "processed_emails.json"), 'w') as f:
            json.dump(processed_data, f, indent=2)
        
        return {"success": True, "action": action_data.action}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to mark email action: {str(e)}")

@app.post("/api/email/{email_id}/to-task")
async def email_to_task(email_id: str, task_data: EmailToTask):
    """Create a Kanban task from an email"""
    try:
        processed_data = load_processed_emails()
        emails = processed_data.get("emails", {})
        
        if email_id not in emails:
            raise HTTPException(status_code=404, detail="Email not found")
        
        email_info = emails[email_id]
        email_data = email_info["email_data"]
        analysis = email_info.get("analysis", {})
        
        # Create task from email
        current_time = datetime.now(timezone.utc).isoformat()
        
        # Build task title and description
        task_title = task_data.task_title or f"📧 {email_data.get('subject', 'Email Task')}"
        
        description_parts = []
        if task_data.task_description:
            description_parts.append(task_data.task_description)
        else:
            description_parts.append(analysis.get("summary", ""))
            if analysis.get("action_needed"):
                description_parts.append(f"Action: {analysis['action_needed']}")
        
        from_info = email_data.get("from", {})
        if isinstance(from_info, dict):
            from_display = f"{from_info.get('name', '')} <{from_info.get('address', '')}>"
        else:
            from_display = str(from_info)
        description_parts.append(f"From: {from_display}")
        
        # Map urgency to energy level
        urgency = analysis.get("urgency", "low")
        energy_map = {"high": "high_burn", "medium": "low_stakes", "low": "brain_dead"}
        energy = energy_map.get(urgency, "low_stakes")
        
        new_task = {
            "id": str(uuid.uuid4()),
            "title": task_title,
            "description": "\n".join(description_parts),
            "column": "unsorted",
            "energy": energy,
            "source_type": "email",
            "source_id": email_id,
            "source_url": email_data.get("webLink", ""),
            "created_at": current_time,
            "updated_at": current_time,
            "stuck_since": current_time
        }
        
        # Add to tasks
        tasks = load_tasks()
        tasks.append(new_task)
        save_tasks(tasks)
        
        # Mark email as converted to task
        emails[email_id]["converted_to_task"] = True
        emails[email_id]["task_id"] = new_task["id"]
        emails[email_id]["converted_at"] = current_time
        
        processed_data["emails"] = emails
        with open(os.path.join(DATA_DIR, "processed_emails.json"), 'w') as f:
            json.dump(processed_data, f, indent=2)
        
        return {"success": True, "task": new_task}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create task from email: {str(e)}")

@app.get("/api/contacts")
async def get_contacts():
    """Get current contact rankings"""
    try:
        contacts = load_contacts()
        return contacts
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get contacts: {str(e)}")

@app.post("/api/contacts/refresh")
async def refresh_contacts():
    """Rebuild contact rankings"""
    try:
        contacts = await refresh_contact_rankings()
        return {"success": True, "contacts": contacts}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to refresh contacts: {str(e)}")


class ContactUpdate(BaseModel):
    list_type: str  # "top20", "top100", "pinned_contacts", "partner_domains"
    email: Optional[str] = None
    domain: Optional[str] = None
    name: Optional[str] = None


@app.post("/api/contacts/add")
async def add_contact(contact: ContactUpdate):
    """Add a contact to a priority list"""
    contacts_path = os.path.join(DATA_DIR, "contacts.json")
    with open(contacts_path) as f:
        contacts = json.load(f)
    
    if contact.list_type == "partner_domains":
        if contact.domain and contact.domain not in contacts.get("partner_domains", []):
            contacts.setdefault("partner_domains", []).append(contact.domain)
    elif contact.list_type in ["top20", "top100", "pinned_contacts"]:
        if contact.email:
            new_contact = {
                "email": contact.email.lower(),
                "name": contact.name or contact.email.split("@")[0],
                "count": 0,
                "domain": contact.email.split("@")[-1] if "@" in contact.email else ""
            }
            contacts.setdefault(contact.list_type, []).append(new_contact)
    
    with open(contacts_path, "w") as f:
        json.dump(contacts, f, indent=2)
    
    return {"success": True, "contacts": contacts}


@app.delete("/api/contacts/remove")
async def remove_contact(list_type: str, email: str = None, domain: str = None):
    """Remove a contact from a priority list"""
    contacts_path = os.path.join(DATA_DIR, "contacts.json")
    with open(contacts_path) as f:
        contacts = json.load(f)
    
    if list_type == "partner_domains" and domain:
        contacts["partner_domains"] = [d for d in contacts.get("partner_domains", []) if d != domain]
    elif list_type in ["top20", "top100", "pinned_contacts"] and email:
        contacts[list_type] = [c for c in contacts.get(list_type, []) if c.get("email", "").lower() != email.lower()]
    
    with open(contacts_path, "w") as f:
        json.dump(contacts, f, indent=2)
    
    return {"success": True, "contacts": contacts}


@app.get("/api/config")
async def get_config():
    """Get pipeline configuration"""
    try:
        config_file = os.path.join(DATA_DIR, "config.json")
        with open(config_file, 'r') as f:
            config = json.load(f)
        return config
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Configuration not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get config: {str(e)}")

@app.put("/api/config")
async def update_config(config: dict):
    """Update pipeline configuration"""
    try:
        config_file = os.path.join(DATA_DIR, "config.json")
        with open(config_file, 'w') as f:
            json.dump(config, f, indent=2)
        return {"success": True, "config": config}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to update config: {str(e)}")

@app.get("/api/brief")
async def get_morning_brief():
    """
    Generate morning brief summary.
    
    Returns a quick overview of today's meetings, tasks by column,
    and identified work windows (gaps between meetings).
    
    Note: This is a legacy endpoint. The /api/briefing endpoint provides
    a more comprehensive briefing with LLM-generated content.
    """
    # Get today's date for the brief
    today = datetime.now(timezone.utc).date()
    
    # Get tasks by column
    tasks = load_tasks()
    task_counts = {}
    for task in tasks:
        column = task["column"]
        task_counts[column] = task_counts.get(column, 0) + 1
    
    # Get calendar events (48-hour lookahead: today + tomorrow, including past events)
    calendar_data = await fetch_from_decapoda("/v1/calendar/today?days=2")
    today_events = []
    
    for event in calendar_data.get("value", []):
        if not event.get("isCancelled", False):
            today_events.append(event)
    
    # Calculate work windows (simplified for MVP)
    # Finds gaps between meetings longer than 1 hour
    work_windows = []
    if today_events:
        sorted_events = sorted(today_events, key=lambda x: x["start"])
        for i in range(len(sorted_events) - 1):
            end_current = datetime.fromisoformat(sorted_events[i]["end"].replace("Z", "+00:00"))
            start_next = datetime.fromisoformat(sorted_events[i + 1]["start"].replace("Z", "+00:00"))
            gap_hours = (start_next - end_current).seconds // 3600
            if gap_hours >= 1:
                work_windows.append(f"{gap_hours}-hour window at {end_current.strftime('%I %p')}")
    
    brief = {
        "date": today.isoformat(),
        "task_counts": task_counts,
        "meeting_count": len(today_events),
        "work_windows": work_windows,
        "summary": f"Today: {len(today_events)} meetings, {sum(task_counts.values())} tasks. " + 
                  (f"{work_windows[0]} for deep work." if work_windows else "No significant work windows.")
    }
    
    return brief

# Triage Mode
@app.get("/triage")
async def triage_page(request: Request):
    """Serve the triage mode page"""
    return templates.TemplateResponse("triage.html", {"request": request})


# Contacts Management
@app.get("/contacts")
async def contacts_page(request: Request):
    """Serve the contacts management page"""
    return templates.TemplateResponse("contacts.html", {"request": request})


# Briefing Routes
@app.get("/briefing")
async def briefing_page(request: Request):
    """Serve the briefing HTML page"""
    return templates.TemplateResponse("briefing.html", {"request": request})

@app.get("/cockpit")
async def cockpit_page():
    """Redirect cockpit to queue (chat panel integrated there)"""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/queue", status_code=302)

@app.get("/api/briefing")
async def get_briefing_data():
    """Get briefing data (from cache if available, otherwise generate fresh)
    
    Runway/Tasks are always fresh (read from tasks.json).
    LLM blocks (pulse, threads) use cache to avoid expensive regeneration.
    """
    from briefing import build_runway_block
    
    try:
        # First check for cached briefing
        cached_briefing = get_cached_briefing()
        if cached_briefing:
            result = cached_briefing["briefing"]
            result["cached"] = True
            result["cached_at"] = cached_briefing["cached_at"]
            
            # Always refresh runway/tasks (real-time, cheap operation)
            tasks = load_tasks()
            fresh_runway = await build_runway_block(tasks)
            result["blocks"]["runway"]["data"] = fresh_runway
            result["blocks"]["runway"]["count"] = len(fresh_runway.get("timeline_items", [])) + len(fresh_runway.get("today_tasks", []))
            
            return result
        
        # No cache exists, generate fresh (blocking)
        briefing_data = await generate_full_briefing()
        briefing_data["cached"] = False
        return briefing_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get briefing: {str(e)}")

@app.post("/api/briefing/refresh")
async def refresh_briefing_data():
    """Force refresh briefing data (bypassing cache)"""
    try:
        # Generate fresh briefing (this saves to cache internally)
        briefing_data = await generate_full_briefing()
        briefing_data["cached"] = False
        return briefing_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to refresh briefing: {str(e)}")

@app.get("/api/briefing/threads")
async def get_briefing_threads():
    """Generate active threads (LLM call)"""
    try:
        processed_emails = load_json_file(os.path.join(DATA_DIR, "processed_emails.json"), {})
        emails = list(processed_emails.get("emails", {}).values())
        tasks = load_json_file(os.path.join(DATA_DIR, "tasks.json"), [])
        
        threads = await generate_active_threads(emails, tasks)
        return {"threads": threads}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate threads: {str(e)}")

@app.get("/api/briefing/pulse")
async def get_briefing_pulse():
    """Generate this week's pulse (LLM call)"""
    try:
        processed_emails = load_json_file(os.path.join(DATA_DIR, "processed_emails.json"), {})
        emails = processed_emails.get("emails", {})
        
        pulse = await generate_weekly_pulse(emails)
        return {"pulse": pulse, "generated_at": datetime.now().isoformat()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate pulse: {str(e)}")

@app.get("/api/briefing/runway")
async def get_briefing_runway():
    """Today's calendar + task timeline"""
    try:
        tasks = load_json_file(os.path.join(DATA_DIR, "tasks.json"), [])
        from briefing import build_runway_block
        runway_data = await build_runway_block(tasks)
        return runway_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate runway: {str(e)}")

@app.post("/api/snooze")
async def snooze_briefing_item(snooze_data: SnoozeRequest):
    """Snooze an item"""
    try:
        snooze_id = snooze_item(
            snooze_data.item_id,
            snooze_data.type,
            snooze_data.source_id,
            snooze_data.title,
            snooze_data.context,
            snooze_data.wake_at,
            snooze_data.original_block
        )
        return {"success": True, "snooze_id": snooze_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to snooze item: {str(e)}")

@app.delete("/api/snooze/{snooze_id}")
async def unsnooze_briefing_item(snooze_id: str):
    """Un-snooze an item"""
    try:
        success = unsnooze_item(snooze_id)
        if success:
            return {"success": True}
        else:
            raise HTTPException(status_code=404, detail="Snoozed item not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to unsnooze item: {str(e)}")

@app.get("/api/snooze")
async def get_snoozed_items():
    """List all snoozed items"""
    try:
        from briefing import load_snoozed_items
        snoozed_data = load_snoozed_items()
        return snoozed_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get snoozed items: {str(e)}")

@app.post("/api/briefing/item/{item_id}/done")
async def mark_briefing_item_done(item_id: str, done_data: ItemDoneRequest):
    """Mark item as handled (remove from briefing)"""
    try:
        success = mark_item_done(item_id, done_data.type)
        if success:
            return {"success": True}
        else:
            raise HTTPException(status_code=404, detail="Item not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to mark item done: {str(e)}")

@app.post("/api/briefing/item/{item_id}/archive")
async def archive_briefing_item(item_id: str, archive_data: ItemDoneRequest):
    """Archive item (mark as not actionable, remove from briefing)"""
    try:
        # Use same logic as done - both remove from active briefing
        success = mark_item_done(item_id, archive_data.type, archived=True)
        if success:
            return {"success": True, "archived": True}
        else:
            raise HTTPException(status_code=404, detail="Item not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to archive item: {str(e)}")

# === Context (Life Domain) Routes ===

@app.get("/api/contexts")
async def list_contexts():
    """List all life domain contexts with status"""
    try:
        contexts = get_contexts()
        active = get_context_filter()
        return {
            "contexts": contexts,
            "active_filter": active
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get contexts: {str(e)}")

@app.post("/api/contexts/filter")
async def set_context_filter_endpoint(filter_data: dict):
    """Set active context filter (None = show all)"""
    try:
        context_id = filter_data.get("context_id")  # None means show all
        set_context_filter(context_id)
        return {"success": True, "active_filter": context_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to set context filter: {str(e)}")

@app.get("/api/contexts/aggregated")
async def get_aggregated_emails_events():
    """Get emails and events from all sources with context tags"""
    try:
        aggregator = get_aggregator()
        data = await aggregator.get_aggregated_data()
        return data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get aggregated data: {str(e)}")

@app.get("/api/accounts")
async def list_accounts():
    """List all email accounts with status"""
    try:
        accounts = get_accounts()
        active = get_account_filter()
        return {
            "accounts": accounts,
            "active_filter": active
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get accounts: {str(e)}")

@app.post("/api/accounts/filter")
async def set_account_filter_endpoint(filter_data: dict):
    """Set active account filter (None = show all)"""
    try:
        account_id = filter_data.get("account_id")  # None means show all
        set_account_filter(account_id)
        return {"success": True, "active_filter": account_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to set account filter: {str(e)}")

@app.get("/api/contexts/{context_id}/accounts")
async def get_context_accounts(context_id: str):
    """Get accounts that feed into a specific context"""
    try:
        accounts = get_accounts_for_context(context_id)
        return {"context_id": context_id, "accounts": accounts}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get accounts for context: {str(e)}")

@app.get("/api/filters")
async def get_all_filters():
    """Get current filter state (both context and account)"""
    try:
        return {
            "contexts": get_contexts(),
            "accounts": get_accounts(),
            "active_context": get_context_filter(),
            "active_account": get_account_filter()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get filters: {str(e)}")

@app.post("/api/filters")
async def set_filters(filter_data: dict):
    """Set both context and account filters at once"""
    try:
        if "context_id" in filter_data:
            set_context_filter(filter_data.get("context_id"))
        if "account_id" in filter_data:
            set_account_filter(filter_data.get("account_id"))
        return {
            "success": True,
            "active_context": get_context_filter(),
            "active_account": get_account_filter()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to set filters: {str(e)}")

@app.get("/api/gmail/test")
async def test_gmail_connection():
    """Test Gmail API connection"""
    try:
        from gmail_client import test_connection
        result = await test_connection()
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gmail test failed: {str(e)}")

# === Health & Monitoring ===

@app.get("/api/health")
async def health_check():
    """Health check endpoint for monitoring"""
    import psutil
    import os
    
    checks = {
        "mission_control": "ok",
        "decapoda_lite": "unknown",
        "gmail": "unknown"
    }
    
    # Check decapoda-lite
    try:
        async with httpx.AsyncClient(timeout=2.0) as client:
            resp = await client.get("http://localhost:8766/admin")
            checks["decapoda_lite"] = "ok" if resp.status_code == 200 else "degraded"
    except Exception:
        checks["decapoda_lite"] = "down"
    
    # Check Gmail
    try:
        from gmail_client import get_client
        client = get_client()
        checks["gmail"] = "ok" if client.is_configured() else "not_configured"
    except Exception:
        checks["gmail"] = "error"
    
    # Memory usage
    process = psutil.Process(os.getpid())
    memory_mb = process.memory_info().rss / 1024 / 1024
    
    overall = "ok" if all(v in ("ok", "not_configured") for v in checks.values()) else "degraded"
    
    return {
        "status": overall,
        "checks": checks,
        "memory_mb": round(memory_mb, 1),
        "uptime_seconds": int(datetime.now(timezone.utc).timestamp() - process.create_time())
    }

@app.get("/api/gmail/emails")
async def get_gmail_emails(days: int = 7, limit: int = 50):
    """Get recent emails from Gmail"""
    try:
        from gmail_client import get_recent_emails
        emails = await get_recent_emails(days_back=days, max_results=limit)
        return {"emails": emails, "count": len(emails)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get Gmail emails: {str(e)}")

@app.get("/api/gmail/events")
async def get_gmail_events(days: int = 7, limit: int = 50):
    """Get upcoming events from Google Calendar"""
    try:
        from gmail_client import get_upcoming_events
        events = await get_upcoming_events(days=days, max_results=limit)
        return {"events": events, "count": len(events)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get Gmail events: {str(e)}")

# === White Paper Index API ===

@app.get("/api/papers/index")
async def get_paper_index():
    """Get the white paper index"""
    try:
        from paper_index import load_index
        index = load_index()
        if not index:
            return {"status": "not_indexed", "message": "Run paper_index.py scan first"}
        return {
            "status": "ok",
            "stats": index.get("stats", {}),
            "by_domain": {k: len(v) for k, v in index.get("by_domain", {}).items()},
            "scanned_at": index.get("scanned_at")
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/papers/search")
async def search_papers(q: str, limit: int = 20):
    """Search white papers"""
    try:
        from paper_index import load_index, search_papers
        index = load_index()
        if not index:
            return {"results": [], "message": "Index not found"}
        results = search_papers(index, q)[:limit]
        return {"query": q, "results": results, "total": len(results)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/papers/domain/{domain}")
async def get_papers_by_domain(domain: str):
    """Get papers in a specific domain"""
    try:
        from paper_index import load_index
        index = load_index()
        if not index:
            return {"papers": []}
        paper_ids = index.get("by_domain", {}).get(domain, [])
        papers = [index["papers"][pid] for pid in paper_ids if pid in index["papers"]]
        return {"domain": domain, "papers": papers, "count": len(papers)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/papers/rescan")
async def rescan_papers():
    """Rescan the papers directory"""
    try:
        from paper_index import scan_papers, save_index
        index = scan_papers()
        save_index(index)
        return {
            "status": "ok",
            "total_papers": index["stats"]["total_papers"],
            "scanned_at": index["scanned_at"]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# Agent Queue Routes
# ============================================================================

@app.get("/queue")
async def queue_page(request: Request):
    """Agent work queue page"""
    return templates.TemplateResponse("queue.html", {"request": request})


@app.get("/api/queue")
async def api_get_queue():
    """Get all queue items and stats"""
    return {
        "items": get_all_items(),
        "by_column": get_items_by_column(),
        "stats": get_stats()
    }


@app.post("/api/queue")
async def api_create_queue_item(item: QueueItemCreate):
    """Create a new queue item"""
    return create_item(item)


@app.get("/api/queue/{item_id}")
async def api_get_queue_item(item_id: str):
    """Get a specific queue item"""
    item = get_item(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item


@app.patch("/api/queue/{item_id}")
async def api_update_queue_item(item_id: str, updates: QueueItemUpdate):
    """Update a queue item"""
    item = update_item(item_id, updates)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item


@app.delete("/api/queue/{item_id}")
async def api_delete_queue_item(item_id: str):
    """Delete a queue item"""
    if not delete_item(item_id):
        raise HTTPException(status_code=404, detail="Item not found")
    return {"status": "deleted", "id": item_id}


class EditRequest(BaseModel):
    path: str


@app.post("/api/queue/edit")
async def api_open_in_editor(request: EditRequest):
    """Open a file in Helix via tmux"""
    result = open_in_helix(request.path)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result.get("error", "Failed to open editor"))
    return result


# ============================================================================
# Agent Orchestration Routes
# ============================================================================

MOLTBOT_GATEWAY = os.environ.get("MOLTBOT_GATEWAY", "http://localhost:18789")
MOLTBOT_TOKEN = os.environ.get("MOLTBOT_TOKEN", "1eba89d56887b8dd1845e1d0898935f8ad378ffc28dd556c")
MOLTBOT_HOME = os.path.expanduser("~/.moltbot")

# Agent definitions (should match moltbot config)
AGENTS = {
    "jarvis": {"name": "Jarvis", "emoji": "🎩", "domain": "AI/Infra", "model": "opus"},
    "aria": {"name": "Aria", "emoji": "📚", "domain": "Research", "model": "sonnet"},
    "peter": {"name": "Peter", "emoji": "📈", "domain": "Finance", "model": "sonnet"},
    "watson": {"name": "Dr. Watson", "emoji": "🩺", "domain": "Medical", "model": "sonnet"},
    "willb": {"name": "Will B.", "emoji": "🏢", "domain": "Novvi", "model": "sonnet"},
    "elon": {"name": "ELon", "emoji": "🚀", "domain": "Startup", "model": "sonnet"},
}

# Context limits by model
MODEL_CONTEXT_LIMITS = {
    "opus": 200000,
    "sonnet": 200000,
}


def get_agent_sessions(agent_id: str) -> dict:
    """Read agent's sessions.json file"""
    sessions_file = os.path.join(MOLTBOT_HOME, "agents", agent_id, "sessions", "sessions.json")
    if os.path.exists(sessions_file):
        try:
            with open(sessions_file, 'r') as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def get_session_token_count(agent_id: str, session_key: str) -> Optional[int]:
    """Read session transcript to estimate token count (from file size as proxy)"""
    sessions = get_agent_sessions(agent_id)
    session_data = sessions.get(session_key, {})
    session_id = session_data.get("sessionId")
    
    if not session_id:
        return None
    
    transcript_file = os.path.join(MOLTBOT_HOME, "agents", agent_id, "sessions", f"{session_id}.jsonl")
    if os.path.exists(transcript_file):
        # Rough estimate: 4 chars per token on average
        file_size = os.path.getsize(transcript_file)
        return file_size // 4
    return None


@app.get("/api/agents")
async def api_get_agents():
    """Get all configured agents with their current status from local session files"""
    agents_status = []
    now = time.time() * 1000  # ms
    
    for agent_id, agent_info in AGENTS.items():
        status = {
            "id": agent_id,
            **agent_info,
            "status": "idle",
            "context_pct": None,
            "session_key": None,
            "updated_ago": None,
        }
        
        try:
            sessions = get_agent_sessions(agent_id)
            main_key = f"agent:{agent_id}:main"
            
            if main_key in sessions:
                session = sessions[main_key]
                status["session_key"] = main_key
                
                # Check if recently active (within 2 hours)
                updated_at = session.get("updatedAt", 0)
                age_ms = now - updated_at
                age_hours = age_ms / (1000 * 60 * 60)
                
                if age_hours < 2:
                    status["status"] = "active"
                    status["updated_ago"] = f"{int(age_ms / 60000)}m ago"
                else:
                    status["status"] = "idle"
                    status["updated_ago"] = f"{int(age_hours)}h ago"
                
                # Estimate context usage
                token_count = get_session_token_count(agent_id, main_key)
                if token_count:
                    context_limit = MODEL_CONTEXT_LIMITS.get(agent_info.get("model"), 200000)
                    status["context_pct"] = min(100, round(100 * token_count / context_limit))
                    
        except Exception as e:
            print(f"[AGENTS] Failed to get status for {agent_id}: {e}")
            status["status"] = "unknown"
        
        agents_status.append(status)
    
    return {"agents": agents_status}


class SpawnRequest(BaseModel):
    agent_id: str
    task: str
    queue_item_id: Optional[str] = None  # Link back to queue item


@app.post("/api/agents/spawn")
async def api_spawn_task(request: SpawnRequest):
    """
    Spawn a task to an agent.
    
    Currently marks the task as pending dispatch - the orchestrator cron job
    or manual /spawn command will pick it up.
    """
    if request.agent_id not in AGENTS:
        raise HTTPException(status_code=400, detail=f"Unknown agent: {request.agent_id}")
    
    # Update queue item to mark it for dispatch
    if request.queue_item_id:
        notes = f"[DISPATCH PENDING] Agent: {request.agent_id}\n---\n{request.task}"
        update_item(request.queue_item_id, QueueItemUpdate(
            column="active",
            session_status="pending",
            notes=notes
        ))
    
    # Create dispatch instruction file for orchestrator to pick up
    dispatch_dir = os.path.join(DATA_DIR, "dispatch_queue")
    os.makedirs(dispatch_dir, exist_ok=True)
    
    dispatch_id = f"d_{datetime.now().strftime('%Y%m%d%H%M%S')}_{request.agent_id}"
    dispatch_file = os.path.join(dispatch_dir, f"{dispatch_id}.json")
    
    with open(dispatch_file, 'w') as f:
        json.dump({
            "id": dispatch_id,
            "agent_id": request.agent_id,
            "task": request.task,
            "queue_item_id": request.queue_item_id,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "status": "pending"
        }, f, indent=2)
    
    return {
        "status": "queued_for_dispatch",
        "dispatch_id": dispatch_id,
        "agent": request.agent_id,
        "message": f"Task queued for {AGENTS[request.agent_id]['name']}. Orchestrator will dispatch shortly."
    }


@app.get("/api/agents/sessions")
async def api_get_sessions():
    """Get all active agent sessions"""
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            response = await client.get(
                f"{MOLTBOT_GATEWAY}/api/sessions",
                headers={"Authorization": f"Bearer {MOLTBOT_TOKEN}"},
                params={"activeMinutes": 60, "messageLimit": 1}
            )
            
            if response.status_code != 200:
                raise HTTPException(status_code=response.status_code, detail="Gateway error")
            
            return response.json()
            
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# Cron Job Routes (proxy to Moltbot gateway)
# ============================================================================

@app.get("/cron")
async def cron_page(request: Request):
    """Cron jobs control panel"""
    return templates.TemplateResponse("cron.html", {"request": request})


def read_cron_jobs_from_file() -> list:
    """Read cron jobs directly from Moltbot's cron state file"""
    cron_file = os.path.join(MOLTBOT_HOME, "cron", "jobs.json")
    if os.path.exists(cron_file):
        try:
            with open(cron_file, 'r') as f:
                data = json.load(f)
                return data.get("jobs", [])
        except Exception as e:
            print(f"[CRON] Failed to read cron file: {e}")
    return []


@app.get("/api/cron/jobs")
async def api_get_cron_jobs():
    """Get all cron jobs"""
    jobs = read_cron_jobs_from_file()
    return {"jobs": jobs}


class CronJobUpdate(BaseModel):
    enabled: Optional[bool] = None
    schedule: Optional[dict] = None


@app.patch("/api/cron/jobs/{job_id}")
async def api_update_cron_job(job_id: str, update: CronJobUpdate):
    """Update a cron job (enable/disable)"""
    # Use the gateway's internal cron API via WebSocket or file
    # For now, we'll update the file directly (simple approach)
    cron_file = os.path.join(MOLTBOT_HOME, "cron", "jobs.json")
    
    try:
        with open(cron_file, 'r') as f:
            data = json.load(f)
        
        jobs = data.get("jobs", [])
        found = False
        for job in jobs:
            if job.get("id") == job_id:
                if update.enabled is not None:
                    job["enabled"] = update.enabled
                    job["updatedAtMs"] = int(time.time() * 1000)
                found = True
                break
        
        if not found:
            raise HTTPException(status_code=404, detail="Job not found")
        
        with open(cron_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        return {"status": "updated", "job_id": job_id}
        
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Cron state file not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/cron/jobs/{job_id}/run")
async def api_run_cron_job(job_id: str):
    """Trigger a cron job to run now"""
    # Update the job's nextRunAtMs to now to trigger immediate run
    cron_file = os.path.join(MOLTBOT_HOME, "cron", "jobs.json")
    
    try:
        with open(cron_file, 'r') as f:
            data = json.load(f)
        
        jobs = data.get("jobs", [])
        found = False
        for job in jobs:
            if job.get("id") == job_id:
                # Set next run to now
                now_ms = int(time.time() * 1000)
                if "state" not in job:
                    job["state"] = {}
                job["state"]["nextRunAtMs"] = now_ms
                job["updatedAtMs"] = now_ms
                found = True
                break
        
        if not found:
            raise HTTPException(status_code=404, detail="Job not found")
        
        with open(cron_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        return {"status": "triggered", "job_id": job_id}
        
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Cron state file not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000)