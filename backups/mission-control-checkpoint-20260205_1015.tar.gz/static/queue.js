// Agent Queue - Mission Control
// Follows the same patterns as app.js

let currentItemId = null;
let currentItem = null;
let items = [];
let agents = [];

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadQueue();
    loadAgentStatus();
    setupEventListeners();
    
    // Refresh agent status every 30s
    setInterval(loadAgentStatus, 30000);
});

function setupEventListeners() {
    // Quick add
    document.getElementById('quick-add-btn').addEventListener('click', quickAdd);
    document.getElementById('quick-add-input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') quickAdd();
    });

    // Drag and drop on content areas
    document.querySelectorAll('.queue-content').forEach(col => {
        col.addEventListener('dragover', handleDragOver);
        col.addEventListener('dragleave', handleDragLeave);
        col.addEventListener('drop', handleDrop);
    });

    // Modal close on backdrop click
    document.getElementById('item-modal').addEventListener('click', (e) => {
        if (e.target.id === 'item-modal') closeModal();
    });

    // Escape key closes modal
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeModal();
    });
    
    // Refresh agents button
    const refreshBtn = document.getElementById('refresh-agents-btn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', loadAgentStatus);
    }
    
    // Cron panel button
    const cronPanelBtn = document.getElementById('cron-panel-btn');
    if (cronPanelBtn) {
        cronPanelBtn.addEventListener('click', openCronPanel);
    }
    
    // Chat panel toggle
    const toggleChatBtn = document.getElementById('toggle-chat-btn');
    if (toggleChatBtn) {
        toggleChatBtn.addEventListener('click', toggleChatPanel);
    }
    
    const closeChatBtn = document.getElementById('close-chat-btn');
    if (closeChatBtn) {
        closeChatBtn.addEventListener('click', () => toggleChatPanel(false));
    }
    
    // Chat agent selector
    const chatAgentSelect = document.getElementById('chat-agent-select');
    if (chatAgentSelect) {
        chatAgentSelect.addEventListener('change', () => {
            loadChatForAgent(chatAgentSelect.value);
        });
    }
}

// ============================================
// Chat Panel Functions
// ============================================

const WEBCHAT_TOKEN = '1eba89d56887b8dd1845e1d0898935f8ad378ffc28dd556c';
const GATEWAY_PORT = 18789;

function getWebchatUrl(agentId) {
    const host = window.location.hostname;
    let baseUrl;
    
    // External access via tunnel
    if (host.includes('jwells.net')) {
        baseUrl = 'https://chat.jwells.net/webchat';
    } else {
        // LAN access - direct to gateway port
        baseUrl = `http://${host}:${GATEWAY_PORT}/webchat`;
    }
    
    let url = `${baseUrl}?token=${WEBCHAT_TOKEN}`;
    if (agentId && agentId !== 'jarvis') {
        url += `&agent=${agentId}`;
    }
    return url;
}

function openCronPanel() {
    const host = window.location.hostname;
    let url;
    if (host.includes('jwells.net')) {
        url = `https://chat.jwells.net/cron?token=${WEBCHAT_TOKEN}`;
    } else {
        url = `http://${host}:${GATEWAY_PORT}/cron?token=${WEBCHAT_TOKEN}`;
    }
    window.open(url, '_blank');
}

function toggleChatPanel(show = null) {
    const panel = document.getElementById('chat-panel');
    if (!panel) return;
    
    const shouldShow = show !== null ? show : panel.classList.contains('hidden');
    panel.classList.toggle('hidden', !shouldShow);
    
    // Load chat if showing and not already loaded
    if (shouldShow) {
        const iframe = document.getElementById('chat-iframe');
        if (!iframe.src) {
            const agentSelect = document.getElementById('chat-agent-select');
            loadChatForAgent(agentSelect ? agentSelect.value : 'jarvis');
        }
    }
}

function loadChatForAgent(agentId) {
    const iframe = document.getElementById('chat-iframe');
    if (iframe) {
        iframe.src = getWebchatUrl(agentId);
    }
}

// ============================================
// Agent Status Functions
// ============================================

async function loadAgentStatus() {
    try {
        const response = await fetch('/api/agents');
        const data = await response.json();
        agents = data.agents || [];
        renderAgentStatus();
    } catch (error) {
        console.error('Failed to load agent status:', error);
    }
}

function renderAgentStatus() {
    const container = document.getElementById('agent-status-list');
    if (!container) return;
    
    container.innerHTML = '';
    
    agents.forEach(agent => {
        const chip = document.createElement('div');
        chip.className = `agent-chip ${agent.status}`;
        chip.dataset.agentId = agent.id;
        
        // Build tooltip
        let tooltip = `${agent.name} (${agent.domain})`;
        if (agent.updated_ago) tooltip += ` - ${agent.updated_ago}`;
        if (agent.context_pct !== null) tooltip += ` - ${agent.context_pct}% context`;
        
        chip.title = tooltip;
        
        chip.innerHTML = `
            <span class="status-dot"></span>
            <span>${agent.emoji} ${agent.name}</span>
            ${agent.context_pct !== null ? `<span class="context-pct">${agent.context_pct}%</span>` : ''}
        `;
        
        chip.addEventListener('click', () => {
            // Pre-select this agent in the quick add
            const agentSelect = document.getElementById('modal-item-agent');
            if (agentSelect) {
                agentSelect.value = agent.id;
            }
            showToast(`${agent.name} selected for dispatch`, 'info');
        });
        
        container.appendChild(chip);
    });
}

async function dispatchToAgent() {
    const agentSelect = document.getElementById('modal-item-agent');
    const agentId = agentSelect.value;
    
    if (!agentId) {
        showToast('Select an agent first', 'error');
        return;
    }
    
    if (!currentItem) {
        showToast('No task selected', 'error');
        return;
    }
    
    // Build task prompt from item
    let task = currentItem.title;
    if (currentItem.description) {
        task += `\n\n${currentItem.description}`;
    }
    if (currentItem.notes) {
        task += `\n\nNotes:\n${currentItem.notes}`;
    }
    if (currentItem.doc_path) {
        task += `\n\nRelevant doc: ${currentItem.doc_path}`;
    }
    
    const dispatchBtn = document.getElementById('dispatch-btn');
    dispatchBtn.disabled = true;
    dispatchBtn.textContent = 'Dispatching...';
    
    try {
        const response = await fetch('/api/agents/spawn', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                agent_id: agentId,
                task: task,
                queue_item_id: currentItem.id
            })
        });
        
        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.detail || 'Spawn failed');
        }
        
        const result = await response.json();
        
        showToast(`Task dispatched to ${agentId}`, 'success');
        closeModal();
        loadQueue();  // Refresh to show updated status
        loadAgentStatus();
        
    } catch (error) {
        console.error('Dispatch failed:', error);
        showToast(`Dispatch failed: ${error.message}`, 'error');
    } finally {
        dispatchBtn.disabled = false;
        dispatchBtn.textContent = 'Dispatch';
    }
}

// ============================================
// API Functions
// ============================================

async function loadQueue() {
    try {
        const response = await fetch('/api/queue');
        const data = await response.json();
        items = data.items || [];
        renderBoard();
        updateStats(data.stats);
    } catch (error) {
        console.error('Failed to load queue:', error);
        showToast('Failed to load queue', 'error');
    }
}

async function createItem(itemData) {
    try {
        const response = await fetch('/api/queue', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(itemData)
        });
        const newItem = await response.json();
        items.push(newItem);
        renderBoard();
        showToast('Task added', 'success');
        return newItem;
    } catch (error) {
        console.error('Failed to create item:', error);
        showToast('Failed to create task', 'error');
    }
}

async function updateItem(itemId, updates) {
    try {
        const response = await fetch(`/api/queue/${itemId}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updates)
        });
        const updatedItem = await response.json();
        
        const index = items.findIndex(i => i.id === itemId);
        if (index !== -1) {
            items[index] = updatedItem;
        }
        renderBoard();
        return updatedItem;
    } catch (error) {
        console.error('Failed to update item:', error);
        showToast('Failed to update task', 'error');
    }
}

async function deleteItem(itemId) {
    try {
        await fetch(`/api/queue/${itemId}`, { method: 'DELETE' });
        items = items.filter(i => i.id !== itemId);
        renderBoard();
        showToast('Task deleted', 'success');
    } catch (error) {
        console.error('Failed to delete item:', error);
        showToast('Failed to delete task', 'error');
    }
}

async function openInEditor(docPath) {
    try {
        const response = await fetch('/api/queue/edit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: docPath })
        });
        const result = await response.json();
        
        if (result.success) {
            showToast(result.message, 'info');
        } else {
            showToast(result.error || 'Failed to open editor', 'error');
        }
    } catch (error) {
        console.error('Failed to open editor:', error);
        showToast('Failed to open editor', 'error');
    }
}

// ============================================
// Render Functions
// ============================================

function renderBoard() {
    const columns = {
        urgent: document.getElementById('col-urgent'),
        active: document.getElementById('col-active'),
        review: document.getElementById('col-review'),
        queued: document.getElementById('col-queued'),
        ideas: document.getElementById('col-ideas')
    };

    // Clear all columns
    Object.values(columns).forEach(col => col.innerHTML = '');

    // Group items by column
    const byColumn = { urgent: [], active: [], review: [], queued: [], ideas: [] };
    items.forEach(item => {
        const col = item.column || 'queued';
        if (byColumn[col]) {
            byColumn[col].push(item);
        }
    });

    // Sort queued by priority (descending)
    byColumn.queued.sort((a, b) => (b.priority || 0) - (a.priority || 0));

    // Render items
    Object.entries(byColumn).forEach(([col, colItems]) => {
        colItems.forEach(item => {
            columns[col].appendChild(createItemCard(item));
        });
        
        // Update count
        const countEl = document.querySelector(`[data-count="${col}"]`);
        if (countEl) countEl.textContent = colItems.length;
    });

    // Update nav stats
    const stats = {
        active: byColumn.active.length,
        queued: byColumn.queued.length,
        review: byColumn.review.length
    };
    updateStats(stats);
}

function createItemCard(item) {
    const card = document.createElement('div');
    card.className = 'queue-item';
    card.draggable = true;
    card.dataset.itemId = item.id;

    // Drag events
    card.addEventListener('dragstart', handleDragStart);
    card.addEventListener('dragend', handleDragEnd);

    // Title (clickable to open modal)
    const title = document.createElement('div');
    title.className = 'queue-item-title';
    title.textContent = item.title;
    title.addEventListener('click', () => openItemModal(item));
    card.appendChild(title);

    // Meta badges row
    const meta = document.createElement('div');
    meta.className = 'queue-item-meta';

    // Complexity badge
    if (item.complexity) {
        const complexityLabels = { quick: 'Quick', medium: 'Medium', deep: 'Deep' };
        const badge = document.createElement('span');
        badge.className = `queue-badge ${item.complexity}`;
        badge.textContent = complexityLabels[item.complexity] || item.complexity;
        meta.appendChild(badge);
    }

    // Doc link badge
    if (item.doc_path) {
        const docBadge = document.createElement('span');
        docBadge.className = 'queue-badge doc';
        docBadge.textContent = 'Doc';
        docBadge.title = item.doc_path;
        docBadge.addEventListener('click', (e) => {
            e.stopPropagation();
            openInEditor(item.doc_path);
        });
        meta.appendChild(docBadge);
    }

    // Running session badge
    if (item.session_status === 'running') {
        const sessionBadge = document.createElement('span');
        sessionBadge.className = 'queue-badge running';
        sessionBadge.textContent = 'Running';
        meta.appendChild(sessionBadge);
    }

    // Priority indicator for queued items
    if (item.column === 'queued' && item.priority > 0) {
        const priorityEl = document.createElement('span');
        priorityEl.className = 'queue-item-priority';
        priorityEl.textContent = `P${item.priority}`;
        meta.appendChild(priorityEl);
    }

    if (meta.children.length > 0) {
        card.appendChild(meta);
    }

    return card;
}

function updateStats(stats) {
    if (!stats) return;
    const el = document.getElementById('queue-stats');
    if (el) {
        el.textContent = `${stats.active || 0} active · ${stats.queued || 0} queued · ${stats.review || 0} review`;
    }
}

// ============================================
// Quick Add
// ============================================

function quickAdd() {
    const input = document.getElementById('quick-add-input');
    const columnSelect = document.getElementById('quick-add-column');
    
    const title = input.value.trim();
    if (!title) return;

    createItem({
        title: title,
        column: columnSelect.value
    });

    input.value = '';
    input.focus();
}

// ============================================
// Drag and Drop
// ============================================

let draggedItem = null;

function handleDragStart(e) {
    draggedItem = e.target;
    e.target.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
}

function handleDragEnd(e) {
    e.target.classList.remove('dragging');
    document.querySelectorAll('.queue-content').forEach(col => {
        col.classList.remove('drag-over');
    });
    draggedItem = null;
}

function handleDragOver(e) {
    e.preventDefault();
    e.currentTarget.classList.add('drag-over');
}

function handleDragLeave(e) {
    e.currentTarget.classList.remove('drag-over');
}

function handleDrop(e) {
    e.preventDefault();
    e.currentTarget.classList.remove('drag-over');
    
    if (!draggedItem) return;
    
    const itemId = draggedItem.dataset.itemId;
    const newColumn = e.currentTarget.closest('.queue-column').dataset.column;
    
    updateItem(itemId, { column: newColumn });
}

// ============================================
// Modal Functions
// ============================================

function openItemModal(item) {
    currentItemId = item.id;
    currentItem = item;  // Store full item for dispatch
    
    document.getElementById('modal-item-id').value = item.id;
    document.getElementById('modal-item-title').value = item.title || '';
    document.getElementById('modal-item-description').value = item.description || '';
    document.getElementById('modal-item-column').value = item.column || 'queued';
    document.getElementById('modal-item-complexity').value = item.complexity || 'medium';
    document.getElementById('modal-item-priority').value = item.priority || 0;
    document.getElementById('modal-item-doc-path').value = item.doc_path || '';
    document.getElementById('modal-item-notes').value = item.notes || '';
    
    // Reset agent dropdown
    const agentSelect = document.getElementById('modal-item-agent');
    if (agentSelect) {
        agentSelect.value = item.assigned_agent || '';
    }
    
    // Dispatch button state
    const dispatchBtn = document.getElementById('dispatch-btn');
    if (dispatchBtn) {
        dispatchBtn.disabled = item.session_status === 'running';
        dispatchBtn.textContent = item.session_status === 'running' ? 'Running...' : 'Dispatch';
    }

    // Session info
    const sessionInfo = document.getElementById('session-info');
    if (item.session_id) {
        sessionInfo.classList.remove('hidden');
        document.getElementById('session-status-text').textContent = 
            `${item.session_id} (${item.session_status || 'unknown'})`;
    } else {
        sessionInfo.classList.add('hidden');
    }

    document.getElementById('item-modal').classList.remove('hidden');
    document.getElementById('modal-item-title').focus();
}

function closeModal() {
    document.getElementById('item-modal').classList.add('hidden');
    currentItemId = null;
    currentItem = null;
}

function saveCurrentItem() {
    if (!currentItemId) return;

    const updates = {
        title: document.getElementById('modal-item-title').value,
        description: document.getElementById('modal-item-description').value,
        column: document.getElementById('modal-item-column').value,
        complexity: document.getElementById('modal-item-complexity').value,
        priority: parseInt(document.getElementById('modal-item-priority').value) || 0,
        doc_path: document.getElementById('modal-item-doc-path').value || null,
        notes: document.getElementById('modal-item-notes').value
    };

    updateItem(currentItemId, updates);
    closeModal();
    showToast('Task updated', 'success');
}

function deleteCurrentItem() {
    if (!currentItemId) return;
    
    if (confirm('Delete this task?')) {
        deleteItem(currentItemId);
        closeModal();
    }
}

function openDocInEditor() {
    const docPath = document.getElementById('modal-item-doc-path').value;
    if (docPath) {
        openInEditor(docPath);
    } else {
        showToast('No document path specified', 'error');
    }
}

// ============================================
// Toast Notifications
// ============================================

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.15s ease';
        setTimeout(() => toast.remove(), 150);
    }, 3000);
}
