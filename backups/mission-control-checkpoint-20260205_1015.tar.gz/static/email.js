/**
 * Mission Control - Email Dashboard JavaScript
 * Handles email dashboard functionality, processing, and UI interactions
 */

class EmailDashboard {
    constructor() {
        this.emails = {};
        this.filteredEmails = {};
        this.stats = {};
        this.lastSync = null;
        this.autoRefreshInterval = null;
        
        this.init();
    }

    async init() {
        this.setupEventListeners();
        this.setupAutoRefresh();
        
        // Initial data load
        await this.loadDashboard();
        
        console.log('📧 Email Dashboard initialized');
    }

    setupEventListeners() {
        // Sync button
        document.getElementById('sync-btn').addEventListener('click', () => this.syncEmails());
        
        // Filtered section toggle
        document.getElementById('filtered-toggle').addEventListener('click', () => this.toggleFiltered());
        
        // Add delegation for email card actions
        document.addEventListener('click', (e) => {
            if (e.target.matches('.task-btn')) {
                const emailId = this.getEmailIdFromElement(e.target);
                this.createTaskFromEmail(emailId);
            } else if (e.target.matches('.archive-btn')) {
                const emailId = this.getEmailIdFromElement(e.target);
                this.archiveEmail(emailId);
            } else if (e.target.matches('.snooze-btn')) {
                const emailId = this.getEmailIdFromElement(e.target);
                this.snoozeEmail(emailId);
            }
        });
    }

    setupAutoRefresh() {
        // Auto-refresh every 5 minutes
        this.autoRefreshInterval = setInterval(() => {
            this.loadDashboard(true); // Silent refresh
        }, 5 * 60 * 1000);
    }

    getEmailIdFromElement(element) {
        const emailCard = element.closest('.email-card');
        return emailCard ? emailCard.dataset.emailId : null;
    }

    // API Methods
    async apiCall(endpoint, options = {}) {
        try {
            const response = await fetch(`/api${endpoint}`, {
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                },
                ...options
            });
            
            if (!response.ok) {
                throw new Error(`API call failed: ${response.statusText}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            if (!options.silent) {
                this.showMessage(`Error: ${error.message}`, 'error');
            }
            throw error;
        }
    }

    async loadDashboard(silent = false) {
        try {
            if (!silent) {
                this.showMessage('Loading dashboard...', 'info');
            }
            
            // Load main dashboard data
            const dashboard = await this.apiCall('/email/dashboard');
            this.updateDashboard(dashboard);
            
            // Load filtered emails for audit section
            const filtered = await this.apiCall('/email/filtered');
            this.updateFilteredSection(filtered.filtered_emails);
            
            if (!silent) {
                this.showMessage('Dashboard updated', 'success');
            }
            
        } catch (error) {
            if (!silent) {
                this.showMessage('Failed to load dashboard', 'error');
            }
        }
    }

    async syncEmails() {
        try {
            this.showLoading(true);
            this.showMessage('Processing emails...', 'info');
            
            const result = await this.apiCall('/email/sync', { method: 'POST' });
            
            await this.loadDashboard(true); // Reload data silently
            
            const message = `Email sync complete: ${result.passed} passed, ${result.filtered} filtered`;
            this.showMessage(message, 'success');
            
        } catch (error) {
            this.showMessage('Email sync failed', 'error');
        } finally {
            this.showLoading(false);
        }
    }

    async createTaskFromEmail(emailId) {
        if (!emailId) return;
        
        try {
            this.showMessage('Creating task...', 'info');
            
            const result = await this.apiCall(`/email/${emailId}/to-task`, {
                method: 'POST',
                body: JSON.stringify({})
            });
            
            this.showMessage('Task created successfully! 📋', 'success');
            
            // Mark email as converted
            const emailCard = document.querySelector(`[data-email-id="${emailId}"]`);
            if (emailCard) {
                emailCard.classList.add('converted-to-task');
                const taskBtn = emailCard.querySelector('.task-btn');
                if (taskBtn) {
                    taskBtn.textContent = '✅ Task Created';
                    taskBtn.disabled = true;
                }
            }
            
        } catch (error) {
            this.showMessage('Failed to create task', 'error');
        }
    }

    async archiveEmail(emailId) {
        if (!emailId) return;
        
        try {
            await this.apiCall(`/email/${emailId}/action`, {
                method: 'POST',
                body: JSON.stringify({ action: 'archive' })
            });
            
            // Remove from dashboard
            const emailCard = document.querySelector(`[data-email-id="${emailId}"]`);
            if (emailCard) {
                emailCard.style.opacity = '0.5';
                emailCard.style.pointerEvents = 'none';
                setTimeout(() => emailCard.remove(), 500);
            }
            
            this.showMessage('Email archived', 'success');
            this.updateStats();
            
        } catch (error) {
            this.showMessage('Failed to archive email', 'error');
        }
    }

    async snoozeEmail(emailId) {
        if (!emailId) return;
        
        try {
            await this.apiCall(`/email/${emailId}/action`, {
                method: 'POST',
                body: JSON.stringify({ action: 'snooze' })
            });
            
            // Remove from dashboard temporarily
            const emailCard = document.querySelector(`[data-email-id="${emailId}"]`);
            if (emailCard) {
                emailCard.style.opacity = '0.5';
                emailCard.style.pointerEvents = 'none';
            }
            
            this.showMessage('Email snoozed for 1 hour', 'success');
            
        } catch (error) {
            this.showMessage('Failed to snooze email', 'error');
        }
    }

    // UI Rendering Methods
    updateDashboard(data) {
        this.emails = data;
        this.stats = data.stats || {};
        
        // Update stats
        this.updateStats();
        
        // Clear and update each section
        this.renderEmailSection('needs_response', data.needs_response || []);
        this.renderEmailSection('action_items', data.action_items || []);
        this.renderEmailSection('meeting_requests', data.meeting_requests || []);
        this.renderEmailSection('fyi', data.fyi || []);
        
        // Update last sync time
        if (data.stats && data.stats.last_sync) {
            const syncTime = new Date(data.stats.last_sync);
            document.getElementById('last-sync').textContent = `Last sync: ${syncTime.toLocaleTimeString()}`;
        }
    }

    updateStats() {
        const stats = this.stats;
        
        document.getElementById('stat-needs-response').textContent = this.emails.needs_response?.length || 0;
        document.getElementById('stat-action-items').textContent = this.emails.action_items?.length || 0;
        document.getElementById('stat-meetings').textContent = this.emails.meeting_requests?.length || 0;
        document.getElementById('stat-fyi').textContent = this.emails.fyi?.length || 0;
        document.getElementById('stat-filtered').textContent = stats.total_filtered || 0;
        
        // Update section counts
        document.getElementById('count-needs-response').textContent = this.emails.needs_response?.length || 0;
        document.getElementById('count-action-items').textContent = this.emails.action_items?.length || 0;
        document.getElementById('count-meetings').textContent = this.emails.meeting_requests?.length || 0;
        document.getElementById('count-fyi').textContent = this.emails.fyi?.length || 0;
        document.getElementById('count-filtered').textContent = Object.keys(this.filteredEmails).length;
    }

    renderEmailSection(sectionName, emails) {
        const listElement = document.getElementById(`list-${sectionName.replace('_', '-')}`);
        if (!listElement) return;
        
        listElement.innerHTML = '';
        
        if (emails.length === 0) {
            listElement.innerHTML = '<div class="empty-state">No emails in this category</div>';
            return;
        }
        
        emails.forEach(email => {
            const emailCard = this.createEmailCard(email);
            listElement.appendChild(emailCard);
        });
    }

    createEmailCard(email) {
        const template = document.getElementById('email-card-template');
        const cardElement = template.content.cloneNode(true);
        const card = cardElement.querySelector('.email-card');
        
        // Set email ID for event handling
        card.dataset.emailId = email.id;
        
        // Sender information
        const senderName = cardElement.querySelector('.sender-name');
        const contactBadge = cardElement.querySelector('.contact-tier-badge');
        
        if (email.from && typeof email.from === 'object') {
            senderName.textContent = email.from.name || email.from.address || 'Unknown';
        } else {
            senderName.textContent = email.from || 'Unknown';
        }
        
        // Contact tier badge
        contactBadge.textContent = this.getContactTierBadge(email.contact_tier);
        contactBadge.className = `contact-tier-badge ${email.contact_tier}`;
        
        // Urgency indicator
        const urgencyIndicator = cardElement.querySelector('.urgency-indicator');
        urgencyIndicator.textContent = this.getUrgencyIndicator(email.urgency);
        urgencyIndicator.className = `urgency-indicator ${email.urgency}`;
        
        // Time
        const emailTime = cardElement.querySelector('.email-time');
        if (email.received) {
            emailTime.textContent = this.formatRelativeTime(email.received);
        }
        
        // Subject and summary
        cardElement.querySelector('.email-subject').textContent = email.subject || 'No subject';
        cardElement.querySelector('.email-summary').textContent = email.summary || 'No summary available';
        
        // Action needed
        if (email.action_needed || email.deadline) {
            const actionDiv = cardElement.querySelector('.email-action');
            actionDiv.style.display = 'block';
            
            if (email.action_needed) {
                cardElement.querySelector('.action-text').textContent = email.action_needed;
            }
            
            if (email.deadline) {
                const deadlineText = cardElement.querySelector('.deadline-text');
                deadlineText.textContent = `⏰ ${email.deadline}`;
                deadlineText.style.display = 'inline';
            }
        }
        
        // Set up action buttons
        const outlookBtn = cardElement.querySelector('.outlook-btn');
        if (email.webLink) {
            outlookBtn.href = email.webLink;
        } else {
            outlookBtn.style.display = 'none';
        }
        
        return cardElement;
    }

    updateFilteredSection(filteredEmails) {
        this.filteredEmails = filteredEmails;
        document.getElementById('count-filtered').textContent = filteredEmails.length;
        
        const listElement = document.getElementById('list-filtered');
        listElement.innerHTML = '';
        
        if (filteredEmails.length === 0) {
            listElement.innerHTML = '<div class="empty-state">No filtered emails</div>';
            return;
        }
        
        filteredEmails.forEach(email => {
            const emailCard = this.createFilteredEmailCard(email);
            listElement.appendChild(emailCard);
        });
    }

    createFilteredEmailCard(email) {
        const template = document.getElementById('filtered-email-template');
        const cardElement = template.content.cloneNode(true);
        
        // Sender information
        const senderName = cardElement.querySelector('.sender-name');
        if (email.from && typeof email.from === 'object') {
            senderName.textContent = `${email.from.name || ''} <${email.from.address || ''}>`;
        } else {
            senderName.textContent = email.from || 'Unknown';
        }
        
        // Time
        const emailTime = cardElement.querySelector('.email-time');
        if (email.received) {
            emailTime.textContent = this.formatRelativeTime(email.received);
        }
        
        // Subject
        cardElement.querySelector('.email-subject').textContent = email.subject || 'No subject';
        
        // Filter reason
        cardElement.querySelector('.filter-text').textContent = email.filter_reason || 'Unknown reason';
        
        return cardElement;
    }

    // Utility Methods
    getContactTierBadge(tier) {
        const badges = {
            'internal': '[NOVVI]',
            'tier1': '[⭐⭐⭐ Top 20]',
            'tier2': '[⭐⭐ Top 100]',
            'partner': '[Partner]',
            'unknown': ''
        };
        return badges[tier] || '';
    }

    getUrgencyIndicator(urgency) {
        const indicators = {
            'high': '🔴',
            'medium': '🟡',
            'low': '🟢'
        };
        return indicators[urgency] || '⚪';
    }

    formatRelativeTime(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diffMs = now - date;
        const diffMins = Math.floor(diffMs / (1000 * 60));
        const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
        const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
        
        if (diffMins < 1) return 'Just now';
        if (diffMins < 60) return `${diffMins}m ago`;
        if (diffHours < 24) return `${diffHours}h ago`;
        if (diffDays < 7) return `${diffDays}d ago`;
        
        return date.toLocaleDateString();
    }

    toggleFiltered() {
        const listElement = document.getElementById('list-filtered');
        listElement.classList.toggle('hidden');
        
        if (!listElement.classList.contains('hidden') && Object.keys(this.filteredEmails).length === 0) {
            // Load filtered emails if not already loaded
            this.loadFilteredEmails();
        }
    }

    async loadFilteredEmails() {
        try {
            const result = await this.apiCall('/email/filtered');
            this.updateFilteredSection(result.filtered_emails);
        } catch (error) {
            console.error('Failed to load filtered emails:', error);
        }
    }

    showLoading(show) {
        const overlay = document.getElementById('loading-overlay');
        if (show) {
            overlay.classList.remove('hidden');
        } else {
            overlay.classList.add('hidden');
        }
    }

    showMessage(text, type = 'info') {
        const message = document.createElement('div');
        message.className = `message ${type}`;
        message.textContent = text;
        document.body.appendChild(message);
        
        setTimeout(() => {
            message.remove();
        }, 3000);
    }
}

// Initialize the email dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.emailDashboard = new EmailDashboard();
});