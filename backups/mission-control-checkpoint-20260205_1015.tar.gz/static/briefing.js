/**
 * =============================================================================
 * Briefing.js - Running Briefing Page Logic
 * =============================================================================
 * 
 * Handles the Running Briefing page which displays:
 * - Decisions Waiting on You (always expanded, high-priority emails)
 * - Today's Runway (horizontal timeline + collapsible tasks)
 * - Active Threads (LLM-generated project clusters)
 * - Incoming Tasks & Action Items (lower-priority emails)
 * - This Week's Pulse (LLM-generated narrative summary)
 * - Stale/Aging (items sitting too long)
 * - Snoozed (temporarily hidden items)
 * 
 * Features:
 * - Auto-refresh every 10 minutes
 * - Snooze system with custom durations
 * - Context/Account filtering
 * - Block collapse/expand with localStorage persistence
 * - Horizontal timeline with overlap detection
 * 
 * Data Flow:
 * - Fetches from /api/briefing (cached) or /api/briefing/refresh (fresh)
 * - Snooze operations: POST /api/snooze, DELETE /api/snooze/:id
 * - Filters: /api/filters, /api/contexts/filter, /api/accounts/filter
 */

console.log('[BRIEFING.JS] VERSION 2026-02-05-v3 loaded at', new Date().toISOString());

// =============================================================================
// Global State
// =============================================================================

let briefingData = null;           // Current briefing data from API
let currentSnoozeItem = null;      // Item being snoozed (for modal)
let contextsData = null;           // Life domain contexts (Novvi, Personal, etc.)
let accountsData = null;           // Email accounts (Office365, Gmail, etc.)
let activeContextFilter = null;    // Current context filter (null = all)
let activeAccountFilter = null;    // Current account filter (null = all)
let globalTimelineItems = [];      // Timeline items for periodic "next event" updates

// Block state (collapsed/expanded) - persisted to localStorage
const blockStates = {
    runway: true,      // Expanded
    threads: true,     // Expanded
    people: true,      // Expanded
    pulse: true,       // Expanded
    stale: false,      // Collapsed by default (less important)
    snoozed: false     // Collapsed by default (out of sight)
};

// =============================================================================
// Initialization
// =============================================================================

document.addEventListener('DOMContentLoaded', function() {
    initializePage();
    // Load filters first, then load briefing data (filters affect rendering)
    loadFilters().then(() => {
        loadBriefingData();
    });
});

// =============================================================================
// Auto-Refresh System
// =============================================================================
// Briefing auto-refreshes every 10 minutes to stay current.
// Manual refresh resets the timer. Countdown shown in nav bar.

const AUTO_REFRESH_INTERVAL_MS = 10 * 60 * 1000; // 10 minutes
let autoRefreshTimer = null;
let lastRefreshTime = null;

function initializePage() {
    // Set up event listeners
    document.getElementById('refresh-btn').addEventListener('click', manualRefresh);
    document.getElementById('retry-btn').addEventListener('click', loadBriefingData);
    
    // Initialize block states
    restoreBlockStates();
    
    // Update current time
    updateCurrentTime();
    setInterval(updateCurrentTime, 60000); // Update every minute
    
    // Start auto-refresh timer (10 minutes)
    startAutoRefreshTimer();
    
    // Update countdown display every minute
    setInterval(updateRefreshCountdown, 60000);
}

function startAutoRefreshTimer() {
    // Clear existing timer if any
    if (autoRefreshTimer) {
        clearInterval(autoRefreshTimer);
    }
    
    lastRefreshTime = Date.now();
    autoRefreshTimer = setInterval(autoRefresh, AUTO_REFRESH_INTERVAL_MS);
    updateRefreshCountdown();
}

async function autoRefresh() {
    console.log('[Auto-refresh] Refreshing briefing data...');
    lastRefreshTime = Date.now();
    await refreshBriefing();
    updateRefreshCountdown();
}

async function manualRefresh() {
    console.log('[Manual refresh] User triggered refresh');
    lastRefreshTime = Date.now();
    await refreshBriefing();
    // Reset the auto-refresh timer on manual refresh
    startAutoRefreshTimer();
}

function updateRefreshCountdown() {
    const countdownEl = document.getElementById('refresh-countdown');
    if (!countdownEl || !lastRefreshTime) return;
    
    const elapsed = Date.now() - lastRefreshTime;
    const remaining = Math.max(0, AUTO_REFRESH_INTERVAL_MS - elapsed);
    const minutesRemaining = Math.ceil(remaining / 60000);
    
    if (minutesRemaining <= 1) {
        countdownEl.textContent = 'refreshing soon...';
    } else {
        countdownEl.textContent = `next refresh in ${minutesRemaining} min`;
    }
}

// =============================================================================
// Filter System (Context + Account)
// =============================================================================
// Contexts: Life domains (Novvi, Personal, Startup, etc.)
// Accounts: Email sources (Office365, Gmail, etc.)
// Both filters are applied server-side and affect which items appear.

async function loadFilters() {
    try {
        const response = await fetch('/api/filters');
        if (!response.ok) {
            console.warn('Failed to load filters, using defaults');
            return;
        }
        
        const data = await response.json();
        contextsData = { contexts: data.contexts };
        accountsData = { accounts: data.accounts };
        activeContextFilter = data.active_context;
        activeAccountFilter = data.active_account;
        
        renderContextFilters(data.contexts);
        renderAccountFilters(data.accounts);
        
        // Load stats for unread counts (async, updates badges when ready)
        loadFilterStats();
        
    } catch (error) {
        console.error('Error loading filters:', error);
    }
}

async function loadFilterStats() {
    try {
        const response = await fetch('/api/contexts/aggregated');
        if (!response.ok) return;
        
        const data = await response.json();
        updateFilterBadges(data.context_stats, data.account_stats);
    } catch (error) {
        console.warn('Could not load filter stats:', error);
    }
}

function updateFilterBadges(contextStats, accountStats) {
    // Update context badges
    if (contextStats) {
        for (const [ctxId, stats] of Object.entries(contextStats)) {
            const btn = document.querySelector(`.context-btn[data-context="${ctxId}"]`);
            if (btn && stats.unread > 0) {
                let badge = btn.querySelector('.ctx-count');
                if (!badge) {
                    badge = document.createElement('span');
                    badge.className = 'ctx-count';
                    btn.appendChild(badge);
                }
                badge.textContent = stats.unread;
            }
        }
    }
    
    // Update account badges  
    if (accountStats) {
        for (const [accId, stats] of Object.entries(accountStats)) {
            const btn = document.querySelector(`.account-btn[data-account="${accId}"]`);
            if (btn && stats.unread > 0) {
                let badge = btn.querySelector('.acc-count');
                if (!badge) {
                    badge = document.createElement('span');
                    badge.className = 'acc-count';
                    btn.appendChild(badge);
                }
                badge.textContent = stats.unread;
            }
        }
    }
}

function renderContextFilters(contexts) {
    const select = document.getElementById('context-filter');
    if (!select) return;
    
    // Build dropdown options
    let html = `<option value="">All Contexts</option>`;
    
    for (const ctx of contexts) {
        if (!ctx.enabled) continue;
        const isSelected = activeContextFilter === ctx.id;
        html += `<option value="${ctx.id}" ${isSelected ? 'selected' : ''}>${ctx.name}</option>`;
    }
    
    select.innerHTML = html;
    
    // Add change listener if not already added
    if (!select.dataset.listenerAdded) {
        select.addEventListener('change', (e) => setContextFilter(e.target.value || null));
        select.dataset.listenerAdded = 'true';
    }
}

async function setContextFilter(contextId) {
    // Update local state
    activeContextFilter = contextId;
    
    // Update dropdown if needed
    const select = document.getElementById('context-filter');
    if (select && select.value !== (contextId || '')) {
        select.value = contextId || '';
    }
    
    // Save filter to backend
    try {
        await fetch('/api/contexts/filter', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ context_id: contextId })
        });
    } catch (error) {
        console.error('Failed to save context filter:', error);
    }
    
    // Re-render briefing with filter applied
    if (briefingData) {
        renderBriefing(briefingData);
    }
}

function getContextBadge(contextId) {
    if (!contextId || !contextsData) return '';
    
    const ctx = contextsData.contexts.find(c => c.id === contextId);
    if (!ctx) return '';
    
    return `<span class="item-context-badge" data-context="${contextId}" style="border-left-color: ${ctx.color}">${ctx.name}</span>`;
}

function filterByContext(items) {
    if (!activeContextFilter || !items) return items;
    return items.filter(item => item.context_id === activeContextFilter);
}

// === Account Filter Functions ===

function renderAccountFilters(accounts) {
    const select = document.getElementById('account-filter');
    if (!select) return;
    
    // Build dropdown options
    let html = `<option value="">All Accounts</option>`;
    
    for (const acc of accounts) {
        if (!acc.enabled) continue;
        const isSelected = activeAccountFilter === acc.id;
        html += `<option value="${acc.id}" ${isSelected ? 'selected' : ''}>${acc.name}</option>`;
    }
    
    select.innerHTML = html;
    
    // Add change listener if not already added
    if (!select.dataset.listenerAdded) {
        select.addEventListener('change', (e) => setAccountFilter(e.target.value || null));
        select.dataset.listenerAdded = 'true';
    }
}

async function setAccountFilter(accountId) {
    // Update local state
    activeAccountFilter = accountId;
    
    // Update dropdown if needed
    const select = document.getElementById('account-filter');
    if (select && select.value !== (accountId || '')) {
        select.value = accountId || '';
    }
    
    // Save filter to backend
    try {
        await fetch('/api/accounts/filter', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ account_id: accountId })
        });
    } catch (error) {
        console.error('Failed to save account filter:', error);
    }
    
    // Re-render briefing with filter applied
    if (briefingData) {
        renderBriefing(briefingData);
    }
}

function getAccountBadge(accountId) {
    if (!accountId || !accountsData) return '';
    
    const acc = accountsData.accounts.find(a => a.id === accountId);
    if (!acc) return '';
    
    return `<span class="item-account-badge" style="border-left: 2px solid ${acc.color}">
        ${acc.icon} ${acc.email.split('@')[0]}
    </span>`;
}

function filterByAccount(items) {
    if (!activeAccountFilter || !items) return items;
    return items.filter(item => item.account_id === activeAccountFilter);
}

function filterItems(items) {
    let filtered = items;
    filtered = filterByContext(filtered);
    filtered = filterByAccount(filtered);
    return filtered;
}

function updateCurrentTime() {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
        timeZone: 'America/Los_Angeles'
    });
    
    const currentTimeEl = document.getElementById('current-time');
    if (currentTimeEl) {
        currentTimeEl.textContent = timeStr;
    }
}

async function loadBriefingData() {
    showLoadingState();
    
    try {
        const response = await fetch('/api/briefing');
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        briefingData = await response.json();
        renderBriefing(briefingData);
        showBriefingContent();
        updateLastUpdated(briefingData);
        
        // Track refresh time for countdown
        lastRefreshTime = Date.now();
        updateRefreshCountdown();
        
    } catch (error) {
        console.error('Failed to load briefing:', error);
        showErrorState();
    }
}

function showLoadingState() {
    document.getElementById('loading-state').classList.remove('hidden');
    document.getElementById('error-state').classList.add('hidden');
    document.getElementById('briefing-container').classList.add('hidden');
}

function showErrorState() {
    document.getElementById('loading-state').classList.add('hidden');
    document.getElementById('error-state').classList.remove('hidden');
    document.getElementById('briefing-container').classList.add('hidden');
}

function showBriefingContent() {
    document.getElementById('loading-state').classList.add('hidden');
    document.getElementById('error-state').classList.add('hidden');
    document.getElementById('briefing-container').classList.remove('hidden');
}

function updateLastUpdated(data) {
    const lastUpdatedEl = document.getElementById('last-updated');
    if (lastUpdatedEl) {
        let text = '';
        let className = 'status-fresh';
        
        if (data.cached && data.cached_at) {
            // Show relative time from cached_at
            const cachedTime = new Date(data.cached_at);
            const now = new Date();
            const minutesAgo = Math.floor((now - cachedTime) / 60000);
            
            if (minutesAgo < 1) {
                text = 'Generated just now';
            } else if (minutesAgo === 1) {
                text = 'Generated 1 min ago';
            } else {
                text = `Generated ${minutesAgo} min ago`;
            }
            
            className = 'status-cached';
        } else if (data.generated_at) {
            // Fresh generation - use pre-formatted string directly
            text = `Updated: ${data.generated_at}`;
            className = 'status-fresh';
        }
        
        lastUpdatedEl.textContent = text;
        lastUpdatedEl.className = className;
        
        // Add cached indicator
        const cachedIndicator = document.getElementById('cached-indicator');
        if (cachedIndicator) {
            if (data.cached) {
                cachedIndicator.style.display = 'inline';
                cachedIndicator.textContent = 'cached';
            } else {
                cachedIndicator.style.display = 'none';
            }
        }
    }
}

function renderBriefing(data) {
    if (!data || !data.blocks) return;
    
    // Render each block
    renderDecisionsBlock(data.blocks.decisions);
    renderRunwayBlock(data.blocks.runway);
    renderThreadsBlock(data.blocks.threads);
    renderPeopleBlock(data.blocks.people);
    renderPulseBlock(data.blocks.pulse);
    renderStaleBlock(data.blocks.stale);
    renderSnoozedBlock(data.snoozed);
}

function renderDecisionsBlock(decisions) {
    const countEl = document.querySelector('#decisions-block .block-count');
    const contentEl = document.getElementById('decisions-content');
    
    if (countEl) countEl.textContent = decisions.count || 0;
    
    if (decisions.count === 0) {
        contentEl.innerHTML = '<div class="empty-state">No pending decisions</div>';
        return;
    }
    
    const itemsHtml = decisions.items.map(item => createDecisionItemHtml(item)).join('');
    contentEl.innerHTML = itemsHtml;
}

function createDecisionItemHtml(item) {
    const template = document.getElementById('decision-item-template');
    const clone = document.importNode(template.content, true);
    
    const itemEl = clone.querySelector('.decision-item');
    itemEl.setAttribute('data-urgency', item.urgency || 'low');
    itemEl.setAttribute('data-id', item.id);
    itemEl.setAttribute('data-type', item.type);
    
    clone.querySelector('.sender-name').textContent = item.sender_name || 'Unknown';
    clone.querySelector('.tier-badge').textContent = item.tier_badge || '';
    clone.querySelector('.decision-days').textContent = `${item.days_waiting || 0} days`;
    clone.querySelector('.decision-subject').textContent = item.subject || 'No subject';
    clone.querySelector('.decision-summary').textContent = item.summary || 'No summary';
    
    // Add click handler for source URL
    if (item.source_url) {
        clone.querySelector('.decision-subject').style.cursor = 'pointer';
        clone.querySelector('.decision-subject').addEventListener('click', () => {
            window.open(item.source_url, '_blank');
        });
    }
    
    const wrapper = document.createElement("div"); wrapper.appendChild(clone); return wrapper.innerHTML;
}

function renderRunwayBlock(runway) {
    const countEl = document.querySelector('#runway-block .block-count');
    const contentEl = document.getElementById('runway-items');
    
    if (countEl) countEl.textContent = runway.count || 0;
    
    if (!runway || runway.count === 0 || runway.count === undefined) {
        contentEl.innerHTML = '<div class="empty-state">No items for today</div>';
        return;
    }
    
    let itemsHtml = '';
    
    // Build horizontal timeline for today's events
    const todayItems = (runway.data.timeline_items || []).filter(item => item.day === 'Today');
    if (todayItems.length > 0) {
        itemsHtml += buildHorizontalTimeline(todayItems);
    }
    
    // Tomorrow items removed - timeline focuses on today only
    
    // Add today tasks in collapsible section
    if (runway.data.today_tasks && runway.data.today_tasks.length > 0) {
        const taskCount = runway.data.today_tasks.length;
        itemsHtml += `
            <div class="tasks-stack collapsed" id="tasks-stack">
                <div class="tasks-stack-header" onclick="toggleTasksStack()">
                    <span class="tasks-stack-arrow">▸</span>
                    <span class="tasks-stack-label">Tasks (${taskCount})</span>
                </div>
                <div class="tasks-stack-content">
        `;
        runway.data.today_tasks.forEach(task => {
            itemsHtml += createTodayTaskHtml(task);
        });
        itemsHtml += `
                </div>
            </div>
        `;
    }
    
    contentEl.innerHTML = itemsHtml;
    
    // Update next event display and store for periodic refresh
    globalTimelineItems = runway.data.timeline_items || [];
    updateNextEventDisplay(globalTimelineItems);
}

/**
 * Create HTML for a single runway item (vertical list format).
 * 
 * NOTE: This is superseded by buildHorizontalTimeline() for calendar events.
 * Kept for potential future use (e.g., detailed event view, accessibility mode).
 * 
 * @param {Object} item - Event/task item with time, title, type, etc.
 * @returns {string} HTML string for the item
 */
function createRunwayItemHtml(item) {
    const template = document.getElementById('runway-item-template');
    const clone = document.importNode(template.content, true);
    
    const itemEl = clone.querySelector('.runway-item');
    
    clone.querySelector('.runway-time').textContent = item.time || '--:--';
    clone.querySelector('.runway-title').textContent = item.title || 'Untitled';
    
    let details = '';
    
    if (item.type === 'meeting') {
        // Style meetings differently
        itemEl.style.borderLeft = '3px solid #00d4aa';
        
        // Show attendee information for meetings
        if (item.attendees_count && item.attendee_names) {
            const attendeeText = item.attendee_names.length > 3 
                ? `${item.attendee_names.slice(0, 3).join(', ')}, ...` 
                : item.attendee_names.join(', ');
            details += `${item.attendees_count} attendees: ${attendeeText}`;
        }
        
        if (item.location) {
            if (details) details += ' • ';
            details += item.location;
        }
        
        // Add click handler for webLink
        if (item.webLink) {
            clone.querySelector('.runway-title').style.cursor = 'pointer';
            clone.querySelector('.runway-title').addEventListener('click', () => {
                window.open(item.webLink, '_blank');
            });
        }
    } else {
        // Regular events or tasks
        if (item.attendees_count) {
            details += `${item.attendees_count} attendees`;
        }
        if (item.location) {
            if (details) details += ' • ';
            details += item.location;
        }
        if (item.prep_notes) {
            if (details) details += ' • ';
            details += item.prep_notes;
        }
    }
    
    clone.querySelector('.runway-details').textContent = details;
    
    // Return as HTML string, not DocumentFragment
    const wrapper = document.createElement('div');
    wrapper.appendChild(clone);
    return wrapper.innerHTML;
}

// NOTE: createWorkWindowHtml() was removed - work_windows feature not yet implemented.
// When implemented, add function here to render work window gaps between meetings.

function createTodayTaskHtml(task) {
    const taskId = task.id || '';
    const sourceUrl = task.source_url || '';
    const openBtn = sourceUrl ? `<button class="task-action-btn" onclick="window.open('${sourceUrl}', '_blank')" title="Open in Office 365">Open</button>` : '';
    
    return `
        <div class="runway-item task-item" data-task-id="${taskId}">
            <div class="runway-time data-text">TASK</div>
            <div class="runway-content">
                <div class="runway-title">${task.title || 'Untitled'}</div>
                <div class="task-actions">
                    ${openBtn}
                    <button class="task-action-btn" onclick="addTaskToKanban('${taskId}')" title="Add to Kanban">+ Kanban</button>
                    <select class="task-snooze-select" onchange="snoozeTask('${taskId}', this.value)" title="Snooze">
                        <option value="">Snooze...</option>
                        <option value="1">1 hour</option>
                        <option value="2">2 hours</option>
                        <option value="4">4 hours</option>
                        <option value="8">8 hours</option>
                        <option value="24">Tomorrow</option>
                    </select>
                    <button class="task-action-btn task-delete-btn" onclick="deleteTask('${taskId}')" title="Delete">✕</button>
                </div>
            </div>
        </div>
    `;
}

function renderThreadsBlock(threads) {
    const countEl = document.querySelector('#threads-block .block-count');
    const contentEl = document.getElementById('threads-content');
    
    if (countEl) countEl.textContent = threads.count || 0;
    
    if (threads.count === 0) {
        contentEl.innerHTML = '<div class="empty-state">No active threads</div>';
        return;
    }
    
    const itemsHtml = threads.items.map(item => createThreadItemHtml(item)).join('');
    contentEl.innerHTML = itemsHtml;
}

function createThreadItemHtml(item) {
    const template = document.getElementById('thread-item-template');
    const clone = document.importNode(template.content, true);
    
    const itemEl = clone.querySelector('.thread-item');
    itemEl.setAttribute('data-id', item.id || '');
    itemEl.setAttribute('data-type', 'thread');
    
    clone.querySelector('.thread-title').textContent = item.title || 'Untitled Thread';
    clone.querySelector('.thread-days').textContent = `${item.days_since_activity || 0} days ago`;
    clone.querySelector('.thread-participants').textContent = 
        item.participants ? `Participants: ${item.participants.join(', ')}` : 'No participants';
    clone.querySelector('.thread-status').textContent = item.status || 'No status';
    clone.querySelector('.thread-next-action').textContent = item.next_action || 'No action defined';
    
    const wrapper = document.createElement("div"); wrapper.appendChild(clone); return wrapper.innerHTML;
}

function renderPeopleBlock(people) {
    const countEl = document.querySelector('#people-block .block-count');
    const contentEl = document.getElementById('people-content');
    
    if (countEl) countEl.textContent = people.count || 0;
    
    if (people.count === 0) {
        contentEl.innerHTML = '<div class="empty-state">No incoming items</div>';
        return;
    }
    
    const itemsHtml = people.items.map(item => createPeopleItemHtml(item)).join('');
    contentEl.innerHTML = itemsHtml;
}

function createPeopleItemHtml(item) {
    const template = document.getElementById('people-item-template');
    const clone = document.importNode(template.content, true);
    
    const itemEl = clone.querySelector('.people-item');
    itemEl.setAttribute('data-id', item.id);
    itemEl.setAttribute('data-type', item.type);
    
    clone.querySelector('.contact-name').textContent = item.name || 'Unknown';
    clone.querySelector('.tier-badge').textContent = item.tier || '';
    clone.querySelector('.people-days').textContent = `${item.days_waiting || 0} days`;
    clone.querySelector('.people-subject').textContent = item.subject || 'No subject';
    clone.querySelector('.people-action').textContent = item.action_needed || 'Review needed';
    
    // Set Open link href
    const openLink = clone.querySelector('.open-link');
    if (item.source_url && openLink) {
        openLink.href = item.source_url;
    } else if (openLink) {
        openLink.style.display = 'none';
        // Hide the separator before it
        const seps = clone.querySelectorAll('.action-sep');
        if (seps.length > 0) seps[seps.length - 1].style.display = 'none';
    }
    
    const wrapper = document.createElement("div"); wrapper.appendChild(clone); return wrapper.innerHTML;
}

function renderStaleBlock(stale) {
    const countEl = document.querySelector('#stale-block .block-count');
    const contentEl = document.getElementById('stale-content');
    
    if (countEl) countEl.textContent = stale.count || 0;
    
    if (stale.count === 0) {
        contentEl.innerHTML = '<div class="empty-state">No stale items</div>';
        return;
    }
    
    const itemsHtml = stale.items.map(item => createStaleItemHtml(item)).join('');
    contentEl.innerHTML = itemsHtml;
}

function createStaleItemHtml(item) {
    const template = document.getElementById('stale-item-template');
    const clone = document.importNode(template.content, true);
    
    const itemEl = clone.querySelector('.stale-item');
    itemEl.setAttribute('data-id', item.id);
    itemEl.setAttribute('data-type', item.type);
    
    clone.querySelector('.stale-title').textContent = item.title || 'Untitled';
    clone.querySelector('.stale-days').textContent = `${item.days_stale || 0}d`;
    clone.querySelector('.stale-source').textContent = item.source || '';
    
    // Set Open link href
    const openLink = clone.querySelector('.open-link');
    if (item.source_url && openLink) {
        openLink.href = item.source_url;
    } else if (openLink) {
        openLink.style.display = 'none';
        // Also hide the separator before it
        const seps = clone.querySelectorAll('.action-sep');
        if (seps.length > 0) seps[seps.length - 1].style.display = 'none';
    }
    
    const wrapper = document.createElement("div"); wrapper.appendChild(clone); return wrapper.innerHTML;
}

function renderPulseBlock(pulse) {
    const contentEl = document.querySelector('#pulse-content .pulse-text');
    const metaEl = document.querySelector('#pulse-generated-at');
    
    if (pulse.content) {
        // Convert bullet points to HTML
        const content = pulse.content.replace(/^• (.+)$/gm, '<li>$1</li>');
        const hasListItems = content.includes('<li>');
        
        if (hasListItems) {
            contentEl.innerHTML = `<ul>${content}</ul>`;
        } else {
            contentEl.innerHTML = `<p>${content}</p>`;
        }
    } else {
        contentEl.innerHTML = '<p>No pulse data available</p>';
    }
    
    if (metaEl && pulse.generated_at) {
        metaEl.textContent = `Generated at: ${pulse.generated_at}`;
    }
}

function renderSnoozedBlock(snoozed) {
    const countEl = document.querySelector('#snoozed-block .block-count');
    const contentEl = document.getElementById('snoozed-content');
    
    if (countEl) countEl.textContent = snoozed.count || 0;
    
    if (snoozed.count === 0) {
        contentEl.innerHTML = '<div class="empty-state">No snoozed items</div>';
        return;
    }
    
    let itemsHtml = '';
    snoozed.items.forEach(item => {
        const wakeDate = new Date(item.wake_at);
        const wakeStr = wakeDate.toLocaleString('en-US', {
            month: 'short',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            timeZone: 'America/Los_Angeles'
        });
        
        itemsHtml += `
            <div class="stale-item" data-snooze-id="${item.id}">
                <div class="stale-content">
                    <div class="stale-header">
                        <span class="stale-title">${item.title}</span>
                        <span class="stale-days data-text">Wake: ${wakeStr}</span>
                    </div>
                    <div class="stale-source">${item.context}</div>
                    <div class="stale-actions">
                        <button class="action-btn" onclick="unsnoozeItem('${item.id}')">Unsnooze</button>
                    </div>
                </div>
            </div>
        `;
    });
    
    contentEl.innerHTML = itemsHtml;
}

// Update block item count (delta: +1 or -1)
function updateBlockCount(blockEl, delta) {
    if (!blockEl) return;
    const countEl = blockEl.querySelector('.block-count');
    if (countEl) {
        const current = parseInt(countEl.textContent) || 0;
        countEl.textContent = Math.max(0, current + delta);
    }
}

// Block toggle functionality
function toggleBlock(blockName) {
    const block = document.getElementById(`${blockName}-block`);
    const arrow = block.querySelector('.block-fold-arrow');
    const isCollapsed = block.classList.contains('collapsed');
    
    if (isCollapsed) {
        block.classList.remove('collapsed');
        arrow.textContent = '▾';
        blockStates[blockName] = true;
    } else {
        block.classList.add('collapsed');
        arrow.textContent = '▸';
        blockStates[blockName] = false;
    }
    
    saveBlockStates();
}

function saveBlockStates() {
    localStorage.setItem('briefing_block_states', JSON.stringify(blockStates));
}

function restoreBlockStates() {
    const saved = localStorage.getItem('briefing_block_states');
    if (saved) {
        try {
            const states = JSON.parse(saved);
            Object.assign(blockStates, states);
        } catch (e) {
            console.warn('Failed to parse saved block states');
        }
    }
    
    // Apply states
    Object.entries(blockStates).forEach(([blockName, isExpanded]) => {
        const block = document.getElementById(`${blockName}-block`);
        if (block) {
            const arrow = block.querySelector('.block-fold-arrow');
            if (isExpanded) {
                block.classList.remove('collapsed');
                if (arrow) arrow.textContent = '▾';
            } else {
                block.classList.add('collapsed');
                if (arrow) arrow.textContent = '▸';
            }
        }
    });
}

// =============================================================================
// Snooze System
// =============================================================================
// Allows temporarily hiding items from the briefing.
// Items reappear when their wake_at time passes (checked on each refresh).
// Snooze data stored server-side in data/snoozed.json.

function openSnoozeModal(buttonEl) {
    const itemEl = buttonEl.closest('[data-id]');
    if (!itemEl) return;
    
    const itemId = itemEl.getAttribute('data-id');
    const itemType = itemEl.getAttribute('data-type');
    let title = 'Unknown Item';
    
    // Get title based on item type
    if (itemType === 'email') {
        const subjectEl = itemEl.querySelector('.decision-subject, .people-subject');
        if (subjectEl) title = subjectEl.textContent;
    } else if (itemType === 'task') {
        const titleEl = itemEl.querySelector('.stale-title, .runway-title');
        if (titleEl) title = titleEl.textContent;
    } else if (itemType === 'thread') {
        const titleEl = itemEl.querySelector('.thread-title');
        if (titleEl) title = titleEl.textContent;
    }
    
    currentSnoozeItem = {
        id: itemId,
        type: itemType,
        title: title,
        element: itemEl
    };
    
    document.getElementById('snooze-item-title').textContent = `Snoozing: ${title}`;
    document.getElementById('snooze-modal').classList.remove('hidden');
    
    // Set up snooze option event listeners
    document.querySelectorAll('.snooze-option[data-hours], .snooze-option[data-days], .snooze-option[data-preset]').forEach(btn => {
        btn.onclick = () => snoozeWithOption(btn);
    });
}

function closeSnoozeModal() {
    document.getElementById('snooze-modal').classList.add('hidden');
    currentSnoozeItem = null;
}

function snoozeWithOption(buttonEl) {
    if (!currentSnoozeItem) return;
    
    const hours = buttonEl.getAttribute('data-hours');
    const days = buttonEl.getAttribute('data-days');
    const preset = buttonEl.getAttribute('data-preset');
    
    let wakeAt;
    const now = new Date();
    
    if (hours) {
        wakeAt = new Date(now.getTime() + parseInt(hours) * 60 * 60 * 1000);
    } else if (days) {
        wakeAt = new Date(now.getTime() + parseInt(days) * 24 * 60 * 60 * 1000);
        wakeAt.setHours(9, 0, 0, 0); // 9 AM PT
    } else if (preset === 'tomorrow') {
        wakeAt = new Date(now);
        wakeAt.setDate(wakeAt.getDate() + 1);
        wakeAt.setHours(9, 0, 0, 0); // 9 AM PT
    } else if (preset === 'next-week') {
        wakeAt = new Date(now);
        const daysToMonday = (8 - wakeAt.getDay()) % 7;
        wakeAt.setDate(wakeAt.getDate() + daysToMonday);
        wakeAt.setHours(9, 0, 0, 0); // 9 AM PT Monday
    }
    
    if (wakeAt) {
        snoozeItem(wakeAt.toISOString());
    }
}

function snoozeToCustomDate() {
    if (!currentSnoozeItem) return;
    
    const dateInput = document.getElementById('custom-snooze-date');
    const dateValue = dateInput.value;
    
    if (!dateValue) {
        alert('Please select a date');
        return;
    }
    
    const wakeAt = new Date(dateValue);
    wakeAt.setHours(9, 0, 0, 0); // 9 AM PT
    
    snoozeItem(wakeAt.toISOString());
}

async function snoozeItem(wakeAt) {
    if (!currentSnoozeItem) return;
    
    const snoozeData = {
        item_id: currentSnoozeItem.id,
        type: currentSnoozeItem.type,
        source_id: currentSnoozeItem.id,
        title: currentSnoozeItem.title,
        context: `Snoozed from briefing`,
        wake_at: wakeAt,
        original_block: getOriginalBlockName(currentSnoozeItem.element)
    };
    
    try {
        const response = await fetch('/api/snooze', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(snoozeData)
        });
        
        if (response.ok) {
            // Remove item from UI and update count
            const block = currentSnoozeItem.element.closest('.briefing-block');
            currentSnoozeItem.element.remove();
            closeSnoozeModal();
            updateBlockCount(block, -1);
        } else {
            alert('Failed to snooze item');
        }
    } catch (error) {
        console.error('Error snoozing item:', error);
        alert('Failed to snooze item');
    }
}

function getOriginalBlockName(itemEl) {
    if (itemEl.closest('#decisions-block')) return 'decisions';
    if (itemEl.closest('#people-block')) return 'people';
    if (itemEl.closest('#threads-block')) return 'threads';
    if (itemEl.closest('#stale-block')) return 'stale';
    return 'unknown';
}

async function unsnoozeItem(snoozeId) {
    try {
        const response = await fetch(`/api/snooze/${snoozeId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            // Remove from snoozed list in UI
            const itemEl = document.querySelector(`[data-snooze-id="${snoozeId}"]`);
            if (itemEl) {
                const block = itemEl.closest('.briefing-block');
                itemEl.remove();
                updateBlockCount(block, -1);
            }
        } else {
            alert('Failed to unsnooze item');
        }
    } catch (error) {
        console.error('Error unsnoozing item:', error);
        alert('Failed to unsnooze item');
    }
}

async function markItemDone(buttonEl) {
    const itemEl = buttonEl.closest('[data-id]');
    if (!itemEl) return;
    
    const itemId = itemEl.getAttribute('data-id');
    const itemType = itemEl.getAttribute('data-type');
    
    try {
        const response = await fetch(`/api/briefing/item/${itemId}/done`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                item_id: itemId,
                type: itemType
            })
        });
        
        if (response.ok) {
            // Remove item from UI and update count
            const block = itemEl.closest('.briefing-block');
            itemEl.remove();
            updateBlockCount(block, -1);
        } else {
            alert('Failed to mark item as done');
        }
    } catch (error) {
        console.error('Error marking item done:', error);
        alert('Failed to mark item as done');
    }
}

async function refreshBriefing() {
    showLoadingState();
    
    try {
        const response = await fetch('/api/briefing/refresh', {
            method: 'POST'
        });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        briefingData = await response.json();
        renderBriefing(briefingData);
        showBriefingContent();
        updateLastUpdated(briefingData);
        
    } catch (error) {
        console.error('Failed to refresh briefing:', error);
        showErrorState();
    }
}

async function refreshPulse() {
    try {
        const response = await fetch('/api/briefing/pulse');
        if (response.ok) {
            const data = await response.json();
            renderPulseBlock(data);
        }
    } catch (error) {
        console.error('Failed to refresh pulse:', error);
    }
}

// Close modal when clicking outside
document.addEventListener('click', function(event) {
    const modal = document.getElementById('snooze-modal');
    if (event.target === modal) {
        closeSnoozeModal();
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeSnoozeModal();
    }
    if (event.key === 'r' && (event.ctrlKey || event.metaKey)) {
        event.preventDefault();
        refreshBriefing();
    }
});

// Make functions globally available
window.toggleBlock = toggleBlock;
window.openSnoozeModal = openSnoozeModal;
window.closeSnoozeModal = closeSnoozeModal;
window.snoozeToCustomDate = snoozeToCustomDate;
window.unsnoozeItem = unsnoozeItem;
window.markItemDone = markItemDone;
window.refreshPulse = refreshPulse;
// Toggle tasks stack collapsed/expanded
function toggleTasksStack() {
    const stack = document.getElementById('tasks-stack');
    if (stack) {
        stack.classList.toggle('collapsed');
    }
}

window.toggleTasksStack = toggleTasksStack;

// Task actions
async function deleteTask(taskId) {
    if (!taskId) return;
    try {
        const response = await fetch(`/api/tasks/${taskId}`, { method: 'DELETE' });
        if (response.ok) {
            const el = document.querySelector(`[data-task-id="${taskId}"]`);
            if (el) el.remove();
            updateTaskCount();
        }
    } catch (e) {
        console.error('Failed to delete task:', e);
    }
}

async function addTaskToKanban(taskId) {
    if (!taskId) return;
    try {
        const response = await fetch(`/api/tasks/${taskId}/to-kanban`, { method: 'POST' });
        if (response.ok) {
            const el = document.querySelector(`[data-task-id="${taskId}"]`);
            if (el) el.remove();
            updateTaskCount();
        }
    } catch (e) {
        console.error('Failed to add to kanban:', e);
    }
}

async function snoozeTask(taskId, hours) {
    if (!taskId || !hours) return;
    try {
        const response = await fetch(`/api/tasks/${taskId}/snooze`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ hours: parseInt(hours) })
        });
        if (response.ok) {
            const el = document.querySelector(`[data-task-id="${taskId}"]`);
            if (el) el.remove();
            updateTaskCount();
        }
    } catch (e) {
        console.error('Failed to snooze task:', e);
    }
}

function updateTaskCount() {
    const stack = document.getElementById('tasks-stack');
    if (stack) {
        const count = stack.querySelectorAll('.task-item').length;
        const label = stack.querySelector('.tasks-stack-label');
        if (label) label.textContent = `Tasks (${count})`;
        if (count === 0) stack.remove();
    }
}

window.deleteTask = deleteTask;
window.addTaskToKanban = addTaskToKanban;
window.snoozeTask = snoozeTask;

// Archive item (similar to done but different semantics - item is not actionable)
async function archiveItem(buttonEl) {
    const itemEl = buttonEl.closest('[data-id]');
    if (!itemEl) return;
    
    const itemId = itemEl.getAttribute('data-id');
    const itemType = itemEl.getAttribute('data-type');
    
    try {
        const response = await fetch(`/api/briefing/item/${itemId}/archive`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                item_id: itemId,
                type: itemType
            })
        });
        
        if (response.ok) {
            // Remove item from UI with a nice fade
            itemEl.style.opacity = '0.5';
            itemEl.style.textDecoration = 'line-through';
            setTimeout(() => {
                const block = itemEl.closest('.briefing-block');
                itemEl.remove();
                updateBlockCount(block, -1);
            }, 300);
        } else {
            alert('Failed to archive item');
        }
    } catch (error) {
        console.error('Error archiving item:', error);
        alert('Failed to archive item');
    }
}

window.archiveItem = archiveItem;

// =============================================================================
// Horizontal Timeline
// =============================================================================

/**
 * Build horizontal timeline visualization for today's calendar events.
 * 
 * Features:
 * - Shows 6 AM - 6 PM by default (expands if events outside this range)
 * - Meeting blocks sized by actual duration
 * - NOW marker with red vertical line
 * - Overlap detection: yellow for 2 meetings, red for 3+ (triple-booked)
 * - Click blocks to open in Office 365
 * - Past events shown with reduced opacity
 * 
 * @param {Array} events - Array of event objects with time, duration_mins, title, webLink
 * @returns {string} HTML string for the timeline
 */
function buildHorizontalTimeline(events) {
    // Determine time range (6 AM to 6 PM default, expand if needed)
    let startHour = 6;
    let endHour = 18;
    
    events.forEach(e => {
        const hour = parseInt(e.time?.split(':')[0] || '12');
        if (hour < startHour) startHour = Math.max(0, hour - 1);
        if (hour >= endHour) endHour = Math.min(24, hour + 2);
    });
    
    const totalHours = endHour - startHour;
    
    // Build hour labels
    let hoursHtml = '';
    for (let h = startHour; h < endHour; h++) {
        const label = h === 0 ? '12a' : h < 12 ? `${h}a` : h === 12 ? '12p' : `${h-12}p`;
        hoursHtml += `<div class="timeline-hour">${label}</div>`;
    }
    
    // Calculate positions and detect overlaps
    const eventBlocks = [];
    events.forEach(event => {
        const [hours, mins] = (event.time || '12:00').split(':').map(Number);
        const startMins = (hours - startHour) * 60 + (mins || 0);
        const durationMins = event.duration_mins || 60; // Default 1 hour if not specified
        
        const leftPercent = (startMins / (totalHours * 60)) * 100;
        const widthPercent = (durationMins / (totalHours * 60)) * 100;
        
        eventBlocks.push({
            ...event,
            left: leftPercent,
            width: Math.max(widthPercent, 3), // Minimum 3% width
            startMins,
            endMins: startMins + durationMins
        });
    });
    
    // Detect overlaps
    eventBlocks.forEach((block, i) => {
        let overlapLevel = 0;
        for (let j = 0; j < i; j++) {
            const other = eventBlocks[j];
            if (block.startMins < other.endMins && block.endMins > other.startMins) {
                overlapLevel = Math.max(overlapLevel, (other.overlapLevel || 0) + 1);
            }
        }
        block.overlapLevel = overlapLevel;
    });
    
    // Current time marker
    const now = new Date();
    const nowHour = now.getHours();
    const nowMin = now.getMinutes();
    const nowMins = (nowHour - startHour) * 60 + nowMin;
    const nowPercent = (nowMins / (totalHours * 60)) * 100;
    const showNowMarker = nowPercent >= 0 && nowPercent <= 100;
    
    // Build event blocks HTML
    let eventsHtml = '';
    eventBlocks.forEach(block => {
        const isPast = block.startMins < nowMins - 30;
        const overlapClass = block.overlapLevel === 1 ? 'overlap' : block.overlapLevel >= 2 ? 'overlap-2' : '';
        const pastClass = isPast ? 'past' : '';
        const url = block.webLink || '';
        const onclick = url ? `onclick="window.open('${url}', '_blank')"` : '';
        
        eventsHtml += `
            <div class="timeline-event ${overlapClass} ${pastClass}" 
                 style="left:${block.left}%; width:${block.width}%;"
                 title="${block.time} - ${block.title}"
                 ${onclick}>
                ${block.title}
            </div>
        `;
    });
    
    // Check for conflicts
    const hasOverlap = eventBlocks.some(b => b.overlapLevel > 0);
    const hasConflict = eventBlocks.some(b => b.overlapLevel >= 2);
    
    return `
        <div class="timeline-horizontal">
            <div class="timeline-hours">${hoursHtml}</div>
            <div class="timeline-events">
                ${eventsHtml}
                ${showNowMarker ? `<div class="timeline-now" style="left:${nowPercent}%"></div>` : ''}
            </div>
        </div>
        ${hasOverlap ? `
        <div class="timeline-legend">
            <span><span class="dot normal"></span> Scheduled</span>
            ${hasOverlap ? '<span><span class="dot overlap"></span> Overlap</span>' : ''}
            ${hasConflict ? '<span><span class="dot conflict"></span> Double-booked!</span>' : ''}
        </div>
        ` : ''}
    `;
}

window.buildHorizontalTimeline = buildHorizontalTimeline;

// Update next event display
function updateNextEventDisplay(timelineItems) {
    const nameEl = document.getElementById('next-event-name');
    const timeEl = document.getElementById('next-event-time');
    
    if (!nameEl || !timeEl) return;
    
    const now = new Date();
    const nowMins = now.getHours() * 60 + now.getMinutes();
    
    // Find next upcoming event (today only)
    const todayItems = (timelineItems || []).filter(item => item.day === 'Today');
    let nextEvent = null;
    let minDiff = Infinity;
    
    todayItems.forEach(item => {
        const [hours, mins] = (item.time || '00:00').split(':').map(Number);
        const eventMins = hours * 60 + mins;
        const diff = eventMins - nowMins;
        
        // Event is in the future and closer than current best
        if (diff > 0 && diff < minDiff) {
            minDiff = diff;
            nextEvent = item;
        }
    });
    
    if (nextEvent) {
        nameEl.textContent = nextEvent.title || 'Untitled';
        
        // Format time remaining
        const hours = Math.floor(minDiff / 60);
        const mins = minDiff % 60;
        let timeStr = '';
        if (hours > 0) {
            timeStr = `in ${hours}h ${mins}m`;
        } else {
            timeStr = `in ${mins}m`;
        }
        timeEl.textContent = timeStr;
    } else {
        nameEl.textContent = 'No more events today';
        timeEl.textContent = '';
    }
}

// Update next event display every minute (uses global globalTimelineItems)
setInterval(() => {
    updateNextEventDisplay(globalTimelineItems);
}, 60000);

window.updateNextEventDisplay = updateNextEventDisplay;
